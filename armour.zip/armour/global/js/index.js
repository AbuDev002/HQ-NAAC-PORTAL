function schools(s2,s3){
			var s2 = document.getElementById(s2);
			var s3 = document.getElementById(s3);
			s3.innerHTML = "0";
			if(s2.value == "School of Science and Technology"){
			var optionArray = ["|","Department of Computer Science|Department of Computer Science","Toro|Toro","Kirfi|Kirfi"];
			} else if(s2.value == "School of Engineering"){
			var optionArray = ["|","avenger|Avenger","challenger|Challenger","charger|Charger"];
			} else if(s2.value == "School of General Studies"){
			var optionArray = ["|","mustang|Mustang","shelby|Shelby"];
			}
			for(var option in optionArray){
			var pair = optionArray[option].split("|");
			var newOption = document.createElement("option");
			newOption.value = pair[0];
			newOption.innerHTML = pair[1];
			s3.options.add(newOption);
			}
			}