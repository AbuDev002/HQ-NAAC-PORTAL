<?php

    class Login_model extends CI_Model{
        public function login_user(){
            $username =  $this->input->post('username');
            $password = $this->input->post('password');
            
            $hash_pass = md5($password);
            
            $sql ="SELECT * FROM users WHERE username ='".$username."' LIMIT 1";
            $result = $this->db->query($sql);
            $row =$result->row();
            
            if($result->num_rows() === 1){
                
                if($row->password === $hash_pass){
                    
                    $session_data = array(
                        'user_id' => $row->user_id,
                        'username'=> $row->username,
                        'firstname'=>$row->firstname
                        );
                    $this->set_session($session_data);
                    return 'logged_in';
                }else{
                    return 'Incorrect password';
                }
            }else{
                return 'Username does not exist';
            }
            
        }
        
        private function set_session($session_data){
            $sess_data = array(
                'user_id' =>$session_data['user_id'],
                'username' =>$session_data['username'],
                'firstname' =>$session_data['firstname'],
                'logged_in' => 1
                
            );
            
            $this->session->set_userdata($sess_datat);
        }
    }
?>
