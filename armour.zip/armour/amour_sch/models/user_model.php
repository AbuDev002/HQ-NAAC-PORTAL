<?php
    class User_model extends CI_Model{
        //this method is adding new army record to the database
       public function insert_soldier($filename){
            //$enc_password = md5($this->input->post('password'));
            $data = array(
                'army_no' => $this->input->post('army_no'),
                'passport' => $filename,
                'surname' => $this->input->post('surname'),
                'firstname' => $this->input->post('firstname'),
                'othername' => $this->input->post('othername'),
                'sex' => $this->input->post('gender'),
                'religion' => $this->input->post('religion'),
                'tribe' => $this->input->post('tribe'),
                'marital_status' => $this->input->post('marital_status'),
                'dob' => $this->input->post('dob'),
                'pob' => $this->input->post('pob'),
                'bgroup' => $this->input->post('bgroup'),
                'height' => $this->input->post('height'),
                'weight' => $this->input->post('weight'),
                'spouse_name' => $this->input->post('spouse_name'),
                'noc' => $this->input->post('noc'),
                'nofc' => $this->input->post('nofc'),
                'state' => $this->input->post('state'),
                'lga' => $this->input->post('lga'),
                'cont_address' => $this->input->post('c_address'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email'),
                'residence_address' => $this->input->post('r_address'),
                'nok_name' => $this->input->post('nok_name'),
                'nok_relationship' => $this->input->post('nok_relation'),
                'nok_address' => $this->input->post('nok_address'),
                'nok_phone' => $this->input->post('nok_phone'),
                'nok2_name' => $this->input->post('nok2_name'),
                'nok2_relationship' => $this->input->post('nok2_relation'),
                'nok2_address' => $this->input->post('nok2_address'),
                'nok2_phone' => $this->input->post('nok2_phone'),
                'rank' => $this->input->post('p_rank'),
                'typeofqualification' => $this->input->post('typeofqualification'),
                //'dateofcommission' => $this->input->post('dateofcommission'),
                'antedate' => $this->input->post('antedate'),
                'date_of_enlist' => $this->input->post('dateofenlistment'),
                //'senioritydate' => $this->input->post('senioritydate'),
                'dateofpromotion' => $this->input->post('dateofpromotion'),
                //'runoutdate' => $this->input->post('runoutdate'),
                'status' => $this->input->post('status'),
                'disciplinary_measure' => $this->input->post('disciplinary_measure'),
                'discip_date' => $this->input->post('dateofdiscip'),
                'offence' => $this->input->post('offence'),
                'nature_of_engagement' => $this->input->post('natureofengagement'),
                'previous_unit' => $this->input->post('previous_unit'),
                'date_served' => $this->input->post('dateserved'),
                'lcpl' => $this->input->post('lcpl'),
                'cpl' => $this->input->post('cpl'),
                'sgt' => $this->input->post('sgt'),
                'ssgt' => $this->input->post('ssgt'),
                'wo' => $this->input->post('wo'),
                'present_unit' => $this->input->post('present_unit'),
                'bank_name' => $this->input->post('bank_name'),
                'bank_address' => $this->input->post('bank_address'),
                'acct_name' => $this->input->post('acct_name'),
                'acct_no' => $this->input->post('acct_no'),
                
                  
            );
            
            $insert = $this->db->insert('soldiers',$data);
            return $insert;
        }
        
           public function edit_soldier($sold_id,$filename){
            //$enc_password = md5($this->input->post('password'));
            $data = array(
                //'army_no' => $this->input->post('army_no'),
                //'passport' => $filename,
                'surname' => $this->input->post('surname'),
                'firstname' => $this->input->post('firstname'),
                'othername' => $this->input->post('othername'),
                'sex' => $this->input->post('gender'),
                'religion' => $this->input->post('religion'),
                'tribe' => $this->input->post('tribe'),
                'marital_status' => $this->input->post('marital_status'),
                'dob' => $this->input->post('dob'),
                'pob' => $this->input->post('pob'),
                'bgroup' => $this->input->post('bgroup'),
                'height' => $this->input->post('height'),
                'weight' => $this->input->post('weight'),
                'spouse_name' => $this->input->post('spouse_name'),
                'noc' => $this->input->post('noc'),
                'nofc' => $this->input->post('nofc'),
                'state' => $this->input->post('state'),
                'lga' => $this->input->post('lga'),
                'cont_address' => $this->input->post('c_address'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email'),
                'residence_address' => $this->input->post('r_address'),
                'nok_name' => $this->input->post('nok_name'),
                'nok_relationship' => $this->input->post('nok_relation'),
                'nok_address' => $this->input->post('nok_address'),
                'nok_phone' => $this->input->post('nok_phone'),
                'nok2_name' => $this->input->post('nok2_name'),
                'nok2_relationship' => $this->input->post('nok2_relation'),
                'nok2_address' => $this->input->post('nok2_address'),
                'nok2_phone' => $this->input->post('nok2_phone'),
                'rank' => $this->input->post('p_rank'),
                'typeofqualification' => $this->input->post('typeofqualification'),
                //'dateofcommission' => $this->input->post('dateofcommission'),
                'antedate' => $this->input->post('antedate'),
                'date_of_enlist' => $this->input->post('dateofenlistment'),
                //'senioritydate' => $this->input->post('senioritydate'),
                'dateofpromotion' => $this->input->post('dateofpromotion'),
                //'runoutdate' => $this->input->post('runoutdate'),
                'status' => $this->input->post('status'),
                'disciplinary_measure' => $this->input->post('disciplinary_measure'),
                'discip_date' => $this->input->post('dateofdiscip'),
                'offence' => $this->input->post('offence'),
                'nature_of_engagement' => $this->input->post('natureofengagement'),
                'previous_unit' => $this->input->post('previous_unit'),
                'date_served' => $this->input->post('dateserved'),
                'lcpl' => $this->input->post('lcpl'),
                'cpl' => $this->input->post('cpl'),
                'sgt' => $this->input->post('sgt'),
                'ssgt' => $this->input->post('ssgt'),
                'wo' => $this->input->post('wo'),
                'present_unit' => $this->input->post('present_unit'),
                'bank_name' => $this->input->post('bank_name'),
                'bank_address' => $this->input->post('bank_address'),
                'acct_name' => $this->input->post('acct_name'),
                'acct_no' => $this->input->post('acct_no'),
                
                  
            );
            
           $this->db->where('sold_id',$sold_id);
           $this->db->update('soldiers',$data);
           return TRUE;
        }
        
        
        //This method is adding new oficer data into the database
        public function insert_officer($filename){
            //$enc_password = md5($this->input->post('password'));
            $data = array(
                'army_no' => $this->input->post('army_no'),
                'passport' => $filename,
                'surname' => $this->input->post('surname'),
                'firstname' => $this->input->post('firstname'),
                'othername' => $this->input->post('othername'),
                'sex' => $this->input->post('gender'),
                'religion' => $this->input->post('religion'),
                'tribe' => $this->input->post('tribe'),
                'marital_status' => $this->input->post('marital_status'),
                'dob' => $this->input->post('dob'),
                'pob' => $this->input->post('pob'),
                'bgroup' => $this->input->post('bgroup'),
                'height' => $this->input->post('height'),
                'weight' => $this->input->post('weight'),
                'spouse_name' => $this->input->post('spouse_name'),
                'noc' => $this->input->post('noc'),
                'nofc' => $this->input->post('nofc'),
                'state' => $this->input->post('state'),
                'lga' => $this->input->post('lga'),
                'cont_address' => $this->input->post('c_address'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email'),
                'residence_address' => $this->input->post('r_address'),
                'nok_name' => $this->input->post('nok_name'),
                'nok_relationship' => $this->input->post('nok_relation'),
                'nok_address' => $this->input->post('nok_address'),
                'nok_phone' => $this->input->post('nok_phone'),
                'nok2_name' => $this->input->post('nok2_name'),
                'nok2_relationship' => $this->input->post('nok2_relation'),
                'nok2_address' => $this->input->post('nok2_address'),
                'nok2_phone' => $this->input->post('nok2_phone'),
                'rank' => $this->input->post('p_rank'),
                'typeofcommission' => $this->input->post('typeofcommission'),
                'dateofcommission' => $this->input->post('dateofcommission'),
                'antedate' => $this->input->post('antedate'),
                'date_of_enlist' => $this->input->post('dateofenlistment'),
                'senioritydate' => $this->input->post('senioritydate'),
                'dateofpromotion' => $this->input->post('dateofpromotion'),
                'runoutdate' => $this->input->post('runoutdate'),
                'status' => $this->input->post('status'),
                'disciplinary_measure' => $this->input->post('disciplinary_measure'),
                'discip_date' => $this->input->post('dateofdiscip'),
                'offence' => $this->input->post('offence'),
                'nature_of_engagement' => $this->input->post('natureofengagement'),
                'previous_unit' => $this->input->post('previous_unit'),
                'date_served' => $this->input->post('dateserved'),
                'present_unit' => $this->input->post('present_unit'),
                'bank_name' => $this->input->post('bank_name'),
                'bank_address' => $this->input->post('bank_address'),
                'acct_name' => $this->input->post('acct_name'),
                'acct_no' => $this->input->post('acct_no'),
                
                  
            );
            
            $insert = $this->db->insert('army_officers',$data);
            return $insert;
        }
        
        //this method is updating the nigerian ary officers data
         public function edit_officer($sold_id){
            //$enc_password = md5($this->input->post('password'));
            $data = array(
                //'army_no' => $this->input->post('army_no'),
                //'passport' => $filename,
                'surname' => $this->input->post('surname'),
                'firstname' => $this->input->post('firstname'),
                'othername' => $this->input->post('othername'),
                'sex' => $this->input->post('gender'),
                'religion' => $this->input->post('religion'),
                'tribe' => $this->input->post('tribe'),
                'marital_status' => $this->input->post('marital_status'),
                'dob' => $this->input->post('dob'),
                'pob' => $this->input->post('pob'),
                'bgroup' => $this->input->post('bgroup'),
                'height' => $this->input->post('height'),
                'weight' => $this->input->post('weight'),
                'spouse_name' => $this->input->post('spouse_name'),
                'noc' => $this->input->post('noc'),
                'nofc' => $this->input->post('nofc'),
                'state' => $this->input->post('state'),
                'lga' => $this->input->post('lga'),
                'cont_address' => $this->input->post('c_address'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email'),
                'residence_address' => $this->input->post('r_address'),
                'nok_name' => $this->input->post('nok_name'),
                'nok_relationship' => $this->input->post('nok_relation'),
                'nok_address' => $this->input->post('nok_address'),
                'nok_phone' => $this->input->post('nok_phone'),
                'nok2_name' => $this->input->post('nok2_name'),
                'nok2_relationship' => $this->input->post('nok2_relation'),
                'nok2_address' => $this->input->post('nok2_address'),
                'nok2_phone' => $this->input->post('nok2_phone'),
                'rank' => $this->input->post('p_rank'),
                'typeofcommission' => $this->input->post('typeofcommission'),
                'dateofcommission' => $this->input->post('dateofcommission'),
                //'dateofcommission' => $this->input->post('dateofcommission'),
                'antedate' => $this->input->post('antedate'),
                'senioritydate' => $this->input->post('senioritydate'),
                'runoutdate' => $this->input->post('runoutdate'),
                'date_of_enlist' => $this->input->post('dateofenlistment'),
                //'senioritydate' => $this->input->post('senioritydate'),
                'dateofpromotion' => $this->input->post('dateofpromotion'),
                //'runoutdate' => $this->input->post('runoutdate'),
                'status' => $this->input->post('status'),
                'disciplinary_measure' => $this->input->post('disciplinary_measure'),
                'discip_date' => $this->input->post('dateofdiscip'),
                'offence' => $this->input->post('offence'),
                'nature_of_engagement' => $this->input->post('natureofengagement'),
                'previous_unit' => $this->input->post('previous_unit'),
                'date_served' => $this->input->post('dateserved'),
                'present_unit' => $this->input->post('present_unit'),
                'bank_name' => $this->input->post('bank_name'),
                'bank_address' => $this->input->post('bank_address'),
                'acct_name' => $this->input->post('acct_name'),
                'acct_no' => $this->input->post('acct_no'),
                
                  
            );
            
           $this->db->where('sold_id',$sold_id);
           $this->db->update('army_officers',$data);
           return TRUE;
        }
        
        public function insert_new_unit(){
            $data = array(
                'unit_name' =>$this->input->post('unit_name'),
                'unit_head' =>$this->input->post('unit_head'),
                'head_psn' =>$this->input->post('head_username'),
                'unit_abbreviation' =>$this->input->post('unit_abbr'),
                'unit_description' =>$this->input->post('unit_description'),
            );
            
            
            $insert = $this->db->insert('units',$data);
            return $insert;
        }
        
        
         public function add_new_course(){
            $data = array(
                'course_name' =>$this->input->post('course_name'),
                'course_qualification' =>$this->input->post('cqualif'),
                
            );
            
            
            $insert = $this->db->insert('courses',$data);
            return $insert;
        }
        
          public function add_news_update(){
            $data = array(
                'news_headline' =>$this->input->post('news_headline'),
                'news_details' =>$this->input->post('news_details'),
                'date_posted' =>$this->input->post('news_date'),
                
            );
            
            
            $insert = $this->db->insert('latest_update',$data);
            return $insert;
        }
        
        public function send_new_notice(){
            $data = array(
                'not_subject' =>$this->input->post('subject'),
                'not_message' =>$this->input->post('message'),
                
            );
            
            
            $insert = $this->db->insert('notice',$data);
            return $insert;
        }
        
        
        
         public function add_new_user(){
             $pass_enc = md5($this->input->post('password'));
            $data = array(
                'username' =>$this->input->post('user_name'),
                'password' =>$pass_enc,
                'security_question' =>$this->input->post('security_question'),
                'security_answer' =>$this->input->post('answer'),
                'unit_name' =>$this->input->post('unit'),
                'status' =>$this->input->post('status'),
                'account_type' =>$this->input->post('account_type'),
            );
            
            
            $insert = $this->db->insert('users',$data);
            return $insert;
        }
        
        //This method authenticate and log the user into the admin section it passes the user_id to the login controller
        public function login_user($username,$password){
            $enc_password = md5($password);
            
            $this->db->where('username',$username);
            $this->db->where('password',$enc_password);
            $this->db->where('status','Active');
            
            $result = $this->db->get('users');
            if($result->num_rows() == 1){
                
                return $result->row();
            }else{
                return false;
            }
        }
        
        /*
        public function update_login($data){
            
             $data = array(
                        "last_login" => $last_login
                    );
             
            $this->db->where('user_id',$this->session->userdata('user_id'));
            $this->db->update("users",$data);
        }
         * 
         */
        //This method will fetch all the units and populate them onto a select box
        public function fetch_units(){
            //$this->db->select('unit_id,unit_name');
            $record = $this->db->get('units');
            return $record->result();
            
            
        }
        
         public function  users(){
              $query = $this->db->get('users');
              return $query->result();
         }
        
        //This method will fetch the list of all state and populate them into a select box
        public function fetch_states(){
            $this->db->select('StateID,StateDesc');
            $record = $this->db->get('state');
            $data = array();
            
            foreach ($record->result() as $row){
                $data[$row->StateDesc] = $row->StateDesc;
            }
            return $data;
            
        }
        
        //This method will get the list of all soldiers from the database
         public function get_all_soldiers(){
              $query = $this->db->get('soldiers');
              return $query->result();
         }
         
          public function get_latest_news($nid){
              $this->db->where('news_id',$nid);
              $query = $this->db->get('latest_update');
              return $query->result();
         }
         
         public function get_latest_update(){
              $query = $this->db->query('select * from latest_update order by news_id desc limit 1');
              return $query->result();
         }
         
         
         public function get_uploaded_file(){
              $query = $this->db->get('uploaded_files');
              return $query->result();
         }
         
          public function get_notice(){
              
              $query = $this->db->query("select * from notice order by not_id desc");
              return $query->result();
         }
         
         //This method will fetch the details biographical data of a single army by passing the army id
         public function get_soldier($sid){
              $this->db->where('sold_id',$sid);
             $query = $this->db->get('soldiers');
           
            return $query->row();
         }
         
         //This method is deleting army record from the database
          public function delete_army($sold_id){
                $this->db->where('sold_id',$sold_id);
                $query =$this->db->delete('soldiers');
                //$this->delete_tasks_of_list($list_id);
                return $query;
            }
            
            
            //for officers----------------------------------------------------------
            //this method will fetch all the list of officers from the database
            public function get_all_officers(){
              $query = $this->db->get('army_officers');
              return $query->result();
         }
         
         //This method will fetch the details biographical data of a single officer by passing the officers id
         public function get_officer($sid){
              $this->db->where('sold_id',$sid);
             $query = $this->db->get('army_officers');
           
            return $query->row();
         }
         
         
         public function get_users(){
              $query = $this->db->get('users');
              return $query->result();
         }
        
         
         //this method will delete the record of a specific officer from the database
          public function delete_officer($sold_id){
                $this->db->where('sold_id',$sold_id);
                $query =$this->db->delete('army_officers');
                //$this->delete_tasks_of_list($list_id);
                return $query;
            }
            
           public function search_na($search){
              //$search = $this->input->post();
              // $sql ="select army_no,passport,surname,firstname,othername,rank from soldiers where army_no like '$user_post' union select army_no,passport,surname,firstname,othername,rank from army_officers where army_no like '$user_post'";
              //$row = array();
             $query = $this->db->query("SELECT sold_id,army_no,passport,surname,firstname,othername,rank FROM soldiers WHERE army_no LIKE '%$search%'");

                if($query-> num_rows() > 0){
                   $output =" <table class='table table-bordered'>";
                    foreach($query->result() as $search_result){
                        $output.="<tr>";
                            $output .="<td rowspan='3'><img src='http://localhost:8080/armour/uploads/passports/$search_result->passport' class='img-thumbnail' width='100' height='100'></td>";
                            $output .="<th> Army No. </th>";
                            $output .="<td colspan='6'>".$search_result->army_no."</td>";
                        
                        $output.="</tr>";
                        
                         $output.="<tr>";
                            
                            $output .="<th> Full Name </th>";
                            $output .="<td colspan='6'>".$search_result->surname."&nbsp; &nbsp;".$search_result->firstname."&nbsp; &nbsp;".$search_result->othername."</td>";
                        
                        $output.="</tr>";
                        
                        $output.="<tr>";
                            
                            $output .="<th> Rank </th>";
                            $output .="<td colspan='6'>".$search_result->rank."</td>";
                        
                        $output.="</tr>";
                        
                        $output.="<tr>";
                            
                            $output .="<th></th>";
                            //$output .="<td colspan='2' align='right'><a onclick='return confirm('Are you sure you want to delete?')' href='http://localhost:8080/armour/admin/delete_soldier/$search_result->sold_id'>Delete Record</a></td>";
                            $output .="<td colspan='2' align='right'><a href='http://localhost:8080/armour/admin/edit_army/$search_result->sold_id'>Edit Record</a></td>";
                            $output .="<td colspan='2' align='right'><a href='http://localhost:8080/armour/admin/army_details/$search_result->sold_id'>More Details</a></td>";
                        
                        $output.="</tr>";
                    }
                   
                   $output .="<table>";
                   return $output;
               }else{
                   return $output ='<p class="text-danger">Sorry No Result Found</p>';
               }
             

           }
           
           
           public function search_nao($searchofficer){
              //$search = $this->input->post();
              // $sql ="select army_no,passport,surname,firstname,othername,rank from soldiers where army_no like '$user_post' union select army_no,passport,surname,firstname,othername,rank from army_officers where army_no like '$user_post'";
              //$row = array();
             $query = $this->db->query("SELECT sold_id,army_no,passport,surname,firstname,othername,rank FROM army_officers WHERE army_no LIKE '%$searchofficer%'");

                if($query-> num_rows() > 0){
                   $output =" <table class='table table-bordered'>";
                    foreach($query->result() as $search_result){
                        $output.="<tr>";
                            $output .="<td rowspan='3'><img src='http://localhost:8080/armour/uploads/passports/$search_result->passport' class='img-thumbnail' width='100' height='100'></td>";
                            $output .="<th> Army No. </th>";
                            $output .="<td colspan='6'>".$search_result->army_no."</td>";
                        
                        $output.="</tr>";
                        
                         $output.="<tr>";
                            
                            $output .="<th> Full Name </th>";
                            $output .="<td colspan='6'>".$search_result->surname."&nbsp; &nbsp;".$search_result->firstname."&nbsp; &nbsp;".$search_result->othername."</td>";
                        
                        $output.="</tr>";
                        
                        $output.="<tr>";
                            
                            $output .="<th> Rank </th>";
                            $output .="<td colspan='6'>".$search_result->rank."</td>";
                        
                        $output.="</tr>";
                        
                        $output.="<tr>";
                            
                            $output .="<th></th>";
                            //$output .="<td colspan='2' align='right'><a onclick='return confirm('Are you sure you want to delete?')' href='http://localhost:8080/armour/admin/delete_soldier/$search_result->sold_id'>Delete Record</a></td>";
                            $output .="<td colspan='2' align='right'><a href='http://localhost:8080/armour/admin/edit_officer/$search_result->sold_id'>Edit Record</a></td>";
                            $output .="<td colspan='2' align='right'><a href='http://localhost:8080/armour/admin/officer_details/$search_result->sold_id'>More Details</a></td>";
                        
                        $output.="</tr>";
                    }
                   
                   $output .="<table>";
                   return $output;
               }else{
                   return $output ='<p class="text-danger">Sorry No Result Found</p>';
               }
             

           }
           
           public function get_search_result($search_criteria,$user_post){
               $query = $this->db->query("select army_no,surname,firstname,othername  from soldiers where $search_criteria like '%$user_post%' union select army_no,surname,firstname,othername  from army_officers WHERE $search_criteria like '%$user_post%'");
               if($query-> num_rows() > 0){
                   $output =" <table class='table table-bordered'>";
                    foreach($query->result() as $search_result){
                       
                         $output.="<tr>";
                            
                            $output.="<td>".$search_result->army_no."</td>";
                            $output .="<td colspan='6'>".$search_result->surname."&nbsp; &nbsp;".$search_result->firstname."&nbsp; &nbsp;".$search_result->othername."</td>";
                        
                        $output.="</tr>";
                        
                       
                    }
                   
                   $output .="<table>";
                   return $output;
               }else{
                   return $output ='<p class="text-danger">Sorry No Result Found</p>';
               }
             
               
           }
           
            public function get_email($army_no){
            $query =$this->db->query("SELECT email FROM soldiers WHERE army_no ='$army_no' UNION SELECT email FROM army_officers WHERE army_no='$army_no' ");
               if($query->num_rows() >0){
                $result = $query->row()->email;
                return $result;
               }else{
                   return $result ='Email Does not Exist or Incorrect PSN No';
               }
        }
        
        public function insert_file_details($filename){
            $data = array(
                'file_name' =>$this->input->post('filename'),
                'file_location' =>$filename,
                );
            $insert_file = $this->db->insert('uploaded_files',$data);
            return $insert_file;
        }
        
        
        public function update_army_credential($filename,$id){
            $data = array(
                //'file_name' =>$this->input->post('filename'),
                'credential' => $filename,
                );
             $this->db->where('sold_id',$id);
             $query = $this->db->update('soldiers',$data);
             return $query;
        }
        
        
        
        public function save_discip_case(){
              
            $data = array(
                'staff_id' => $this->input->post('staffid'),
                'offence' => $this->input->post('offence'),
                'action' => $this->input->post('action'),
                'date' => $this->input->post('date'),
                );
             $query = $this->db->insert('displinary_case',$data);
             return $query;
        }
        
        public function save_commander_profile($filename){
              
            $data = array(
                'com_passport' => $filename,
                'com_name' => $this->input->post('com_name'),
                'rank' => $this->input->post('rank'),
                'datefrom' => $this->input->post('datefrom'),
                'dateto' => $this->input->post('dateto'),
                );
             $query = $this->db->insert('pass_commanders',$data);
             return $query;
        }
        
        //this method is trying to update unit history when ever there is update in the unit page
        public function update_unit_history($sold_id){
            $data = array(
                'present_unit' => $this->input->post('present_unit')
                );
                $this->db->where('staff_id',$sold_id);
                $this->db->update('unit_history',$data);
                return true;
        }
}

?>