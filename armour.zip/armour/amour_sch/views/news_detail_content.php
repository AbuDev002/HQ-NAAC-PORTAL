<div id='outside_content'>
    <div id='outside_content_header'>
        Latest News Update
    </div>
    <br/>
    
    <?php foreach($news_update as $update):?>
        <p><b>Posted On:&nbsp;</b><?php echo $update->date_posted;?></p>
        <p><b>Headline:&nbsp;</b><?php echo $update->news_headline;?></p>
        <p><b>Details:&nbsp;</b><?php echo $update->news_details;?></p>
    <?php endforeach;?>
</div>