<div id='outside_content'>
    <div id='outside_content_header'>
        Calender of Events
    </div>
    <br/>
    <p>Nigerian Army Armoured Corps annual activities splits into 12 month of the year fall into the following categories</p>
    <p><ol>
            <li>FTX/CPX</li>
            <li>Competition</li>
            <li>Exam</li>
            <li>CONF</li>
            <li>SIMEX</li>
            <li>Workshops/Seminars</li>
            <li>Visits</li>
            <li>Social Activities</li>
            <li>TRG</li>
            <li>Sport</li>
            <li>Test</li>
    </ol></p>
    <br/>
    <br/>
    <?php foreach($files as $file):?>
    <p><b><?php echo $file->file_name;?></b> &nbsp; &nbsp; <a href='<?php echo base_url()?>/uploads/uploaded_files/<?php echo $file->file_location;?>'>Download</a></p>
    
    <?php endforeach;?>
</div>