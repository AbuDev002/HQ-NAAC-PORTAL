<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Welcome to the Admin Area. This is where the Supper Administrator can manage all files </p></div>
            <br/>
            <br/>
            <center><img src="<?php echo base_url();?>global/images/admintk.jpg" class="img-thumbnail"></center>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>