<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Add Past Commanders Profile </p></div>
            <br/>
           <center> <?php echo validation_errors('<p class="text-danger">');?></center>
           <?php if($this->session->flashdata('record_uploaded')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('record_uploaded');?></p>
            <?php endif;?>
              
               
            <?php echo form_open_multipart('admin/add_commander')?>
    <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    
                    <tr>
                        <td>Passport</td>
                        <td height="50">
                            <input type="file" name="commander_image" size="20" />

                       </td>
                    </tr>
                    
                     <tr>
                        <td></td>
                       
                    </tr>
                    <tr>
                        <td>Name:</td>
                        <td height="50">
                            <?php echo form_input('com_name',  set_value('com_name'));?>

                       </td>
                    </tr>
                    <tr>
                        <td>Rank:</td>
                        <td height="50">
                            <?php echo form_input('rank',  set_value('rank'));?>

                       </td>
                    </tr>
                    <tr>
                        <td>Date From:</td>
                        <td height="50">
                            <?php echo form_input('datefrom',  set_value('datefrom'));?>

                       </td>
                    </tr>
                    <tr>
                        <td>Date To:</td>
                        <td height="50">
                            <?php echo form_input('dateto',  set_value('dateto'));?>

                       </td>
                    </tr>
                    
                     <tr>
                        <td></td>
                       
                    </tr>
                    <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnCredential',
                                'id'  =>'Credential',
                                'value' =>'Add'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>