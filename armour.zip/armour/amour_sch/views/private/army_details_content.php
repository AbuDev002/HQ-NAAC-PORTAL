<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Details of Nigerian Army Record </p></div>
                <div class="panel panel-success">
					<div class="panel-heading">
						<b><?php echo $army->surname.'   '.$army->firstname.'  '.$army->othername;?> (Personal Information)</b>
					</div>
					<div class="panel-body">
						<div class="panel panel-success">
						<table class="table table-hover">
						<tr>
						
						<div class="panel-heading">

						</tr>
						<tr>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
						</tr>
						</div>
						<br/>
							
							<div class="panel-body">
								<table class="table table-bordered">
                                    <tr>
                                        <td></td>
										<th>Army No.</th>
										<td><?php echo $army->army_no; ?></td>
										
									</tr>
									<tr>
										<td rowspan="3"><img src="<?php echo base_url()?>uploads/passports/<?php echo $army->passport;?>" class="img-thumbnail" width="100" height="100"></td>
										<th>Full Name</th>
										<td><?php echo $army->surname.'   '.$army->firstname.'  '.$army->othername;?></td>
									</tr>
									
									<tr>
										<th>Rank</th>
										<td><?php echo $army->rank?></td>
										
									</tr>
									<tr>
										<th></th>
										
									</tr>
						
									
								</table>
								
							
								
							</div>
								<ul class="nav nav-tabs">
								  <li class="active"><a href="#personal_details" data-toggle="tab">Nigerian Army Personal Information</a></li>
								</ul>
								
								<div class="tab-content">
									<div class="tab-pane active" id="personal_details">
										<table class="table table-bordered">
											<tr class="success">
												<td colspan="5" align="center"><b>Bio Data</b></td>
											</tr>
											<tr>
												<th>Sur Name</th>
												<td><?php echo $army->surname;?></td>
                                                <th>First Name</th>
												<td><?php echo $army->firstname;?></td>
												<th>Other Name</th>
												<td><?php echo $army->othername;?></td>
												
											</tr>
											<tr>
												<th>Date of Birth</th>
												<td><?php echo $army->dob;?></td>
												<th>Sex</th>
												<td colspan="3"><?php echo $army->sex;?></td>
											</tr>
											<tr>
												<th>Place of Birth</th>
												<td><?php echo $army->pob;?></td>
												<th>State of Origin</th>
												<td colspan="3"><?php echo $army->state;?></td>
											</tr>
											<tr>
												<th>LGA</th>
												<td><?php echo $army->lga;?></td>
												<th>Contact Address</th>
												<td colspan="3"><?php echo $army->cont_address;?></td>
											</tr>
											<tr>
												<th>Mobile No.</th>
												<td><?php echo $army->phone;?></td>
												<th>Date of Enlistment</th>
												<td colspan="3"><?php echo $army->date_of_enlist;?></td>
											</tr>
                                            <tr>
												<th>Religion.</th>
												<td><?php echo $army->religion;?></td>
												<th>Tribe</th>
												<td colspan="3"><?php echo $army->tribe;?></td>
											</tr>
                                            <tr>
												<th>Marital Status.</th>
												<td><?php echo $army->marital_status;?></td>
												<th>Blood Group</th>
												<td colspan="3"><?php echo $army->bgroup;?></td>
											</tr>
                                            <tr>
												<th>Height(ft)</th>
												<td><?php echo $army->height;?></td>
												<th>Weight(kg)</th>
												<td colspan="3"><?php echo $army->weight;?></td>
											</tr>
                                            <tr>
												<th>Email</th>
												<td><?php echo $army->email;?></td>
												
											</tr>
											<tr class="success">
												<td colspan="5" align="center"><b>Next of I</b></td>
											</tr>
											<tr>
												<th>Next of Kin Name</th>
												<td><?php echo $army->nok_name;?></td>
												<th>Next of Kin Relationship</th>
												<td><?php echo $army->nok_relationship;?><td>
											</tr>
											<tr>
												<th>Next of Kin Address</th>
												<td><?php echo $army->nok_address;?></td>
                                                <th>Next of Kin Phone</th>
												<td><?php echo $army->nok_phone;?></td>
												
											</tr>
                                            <tr class="success">
												<td colspan="5" align="center"><b>Next of II</b></td>
											</tr>
											<tr>
												<th>Next of Kin Name</th>
												<td><?php echo $army->nok2_name;?></td>
												<th>Next of Kin Relationship</th>
												<td><?php echo $army->nok2_relationship;?><td>
											</tr>
											<tr>
												<th>Next of Kin Address</th>
												<td><?php echo $army->nok2_address;?></td>
                                                <th>Next of Kin Phone</th>
												<td><?php echo $army->nok2_phone;?></td>
												
											</tr>
											<tr class="success">
												<td colspan="5" align="center"><b>Official Details</b></td>
											</tr>
											<tr>
												<th>Present Rank</th>
												<td><?php echo $army->rank;?></td>
												<th>Type of Qualification</th>
												<td><?php echo $army->typeofqualification;?></td>
											</tr>
											<tr>
												<th>Ante Date</th>
												<td><?php echo $army->antedate;?></td>
												<th>Disciplinary Measure</th>
												<td><?php echo $army->disciplinary_measure;?></td>
											</tr>
											<tr>
												<th>Offense</th>
												<td><?php echo $army->offence;?></td>
												<th>Date of Promotion</th>
												<td><?php echo $army->dateofpromotion;?></td>
												
											</tr>
                                            <tr>
												<th>Previous Unit</th>
												<td><?php echo $army->previous_unit;?></td>
												<th>Date served</th>
												<td><?php echo $army->date_served;?></td>
												
											</tr>
                                            <tr>
												<th>Present Unit</th>
												<td><?php echo $army->present_unit;?></td>
												<th>Date of Discipline</th>
												<td><?php echo $army->discip_date;?></td>
												
											</tr>
                                            <tr>
												<th>Nature of Engagement</th>
												<td><?php echo $army->nature_of_engagement;?></td>
												
											</tr>
                                            <tr class="success">
												<td colspan="5" align="center"><b>Promotion History</b></td>
											</tr>
                                            <tr>
												<th>LCPL</th>
												<th>Part 2 Order</th>
												<td><?php echo $army->lcpl;?></td>
												
											</tr>
                                            <tr>
												<th>CPL</th>
												<th>Part 2 Order</th>
												<td><?php echo $army->cpl;?></td>
												
											</tr>
                                            <tr>
												<th>SGT</th>
												<th>Part 2 Order</th>
												<td><?php echo $army->sgt;?></td>
												
											</tr>
                                            <tr>
												<th>SSGT</th>
												<th>Part 2 Order</th>
												<td><?php echo $army->ssgt;?></td>
												
											</tr>
                                            <tr>
												<th>WO</th>
												<th>Part 2 Order</th>
												<td><?php echo $army->wo;?></td>
												
											</tr>
											<tr class="success">
												<td colspan="5" align="center"><b>Bank Details</b></td>
											</tr>
                                            
											<tr>
												<th>Bank Name</th>
												<td><?php echo $army->bank_name;?></td>
												<th>Bank Address</th>
												<td><?php echo $army->bank_address;?></td>
												
											</tr>
											<tr>
												<th>Account Name</th>
												<td><?php echo $army->acct_name;?></td>
												<th>Account No</th>
												<td><?php echo $army->acct_no;?></td>
												
											</tr>
											
										</table>
										<hr />
										<center><button type="button"><a href="#">View As Report</a></button></center>
									</div>
									
								</div>
						</div>
					</div>
				</div>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>