<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Add Latest News </p></div>
            <br/>
            <br/>
            <?php if($this->session->flashdata('news_added')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('news_added');?></p>
            <?php endif;?>
            <center><?php echo validation_errors('<p class="text-danger">')?></center>
            <?php echo form_open('admin/latest_update');?>
                <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    <tr>
                        <td align="right"><?php //echo form_label('Course Name:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'news_headline',
                                'id'  =>'news_headline',
                                'placeholder'  =>'Enter news headline...',
                                'style' =>'width:100%',
                                'value' =>set_value('news_headline')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                   <tr>
                        <td><br/></td>
                    </tr>
                    <tr>
                        <td align="right"><?php //echo form_label('Course Name:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'news_date',
                                'class'  =>'date',
                                'placeholder'  =>'Click To Add Date...',
                                'style' =>'width:100%',
                                'value' =>set_value('news_date')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                   
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td valign="top" align="right"><?php //echo form_label('Course Qualification:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'news_details',
                                'id'  =>'news_details',
                                'placeholder'  =>'Write news details....',
                                'style' =>'width:100%',
                                'value' =>set_value('news_details')
                            );?>
                            <?php echo form_textarea($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnLatest',
                                'id'  =>'cname',
                                'value' =>'Add News Update'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>


<script type="text/javascript">
	$.datepicker.setDefaults({
		changeMonth : true,
		changeYear  : true,
		dateFormat  :'yy/mm/dd'
		
	});
	
	$(function(){
		$('.date').datepicker();
		$('body').delegate('input[type=date]',click,function(e)
		{
			$(this).datepicker();
		
		});
	});

</script>