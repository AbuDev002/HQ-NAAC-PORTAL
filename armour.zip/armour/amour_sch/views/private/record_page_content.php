<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Search With Criteria </p></div>
                <br/>
                <center><?php echo validation_errors('<p class="text-danger">');?></center>
                <?php echo form_open('admin/records_page');?>
                    <table width="100%" align="center" >
                        <!--
                        <td>Select From</td>
                        <td>
                            <select name="tblname" style="width:100%">
                                <option value="">--Select--</option>
                                <option value="soldiers">Soldiers</option>
                                <option value="army_officers">Officers</option>
                            </select>
                        </td>
                        
                        <td>Search For</td>
                        -->
                        <td>
                            <select name="qdata" style="width:100%">
                                <option value="">--Select--</option>
                                <option value="army_no">Army NO</option>
                                <option value="PS_no">PSN NO</option>
                                <option value="present_unit">Unit</option>
                                <option value="dateofpromotion">Promotion Date</option>
                                <option value="date_of_enlist">Date of Enlistment</option>
                                <option value="status">Status</option>
                                <option value="typeofcommission">Type of Commission</option>
                                <option value="bank_name">Bank</option>
                                <option value="courses_attended">Course Attended</option>
                                <option value="operation_participated">Operation Participated</option>
                                <option value="disciplinary_case">Disciplinary Case</option>
                            </select>
                        </td>
                        
                        <td align="right"><?php echo form_label('Search:', 'search-box'); ?></td>
                        <td><input type='text' name='sfield' placeholder='Search....'> <?php echo form_submit('search','Search'); ?></td>
                        <td></td>
                        
                    </table>
                <?php echo form_close();?>
                
                <br/>
                <br/>
                
                <?php echo $results;?>
                
                
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>