<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Checks When User Logs Into the System </p></div>
    
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>