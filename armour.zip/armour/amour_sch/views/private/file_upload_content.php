<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Upload A New File </p></div>
            <br/>
           <center> <?php echo validation_errors('<p class="text-danger">');?></center>
           <?php if($this->session->flashdata('file_uploaded')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('file_uploaded');?></p>
            <?php endif;?>
              
            <?php echo form_open_multipart('admin/upload_file')?>
    <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    
        
                   
                      <tr>
                        <td><?php echo form_label('Enter File Name:');?></td>
                        <td colspan="2">
                       
                            <?php $data = array(
                                'name' =>'filename',
                                'id'  =>'filename',
                                'style' =>'width:100%',
                               
                            );?>
                            <?php echo form_input($data);?>
                            
                        </td>
                         
                    </tr> 
                    <tr>
                        <td></td>
                        <td height="50">
                            <input type="file" name="file_upload" size="20" />

                       </td>
                    </tr>
                    
                     <tr>
                        <td></td>
                       
                    </tr>
                    <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnUpload',
                                'id'  =>'upload',
                                'value' =>'Upload'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>