<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Nigerian Army Officers Information Details </p></div>
            <br/>
            <br/>
            <?php if($this->session->flashdata('army_deleted')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('army_deleted');?></p>
            <?php endif;?>
                 <?php echo validation_errors()?>
               <?php echo form_open('admin/searchnao'); ?>
                <table cellspacing="5" cellpadding="5" align="right">
                    <tr>
                        <td><input type='text' name='searchofficer'  placeholder='Search PSN No...' /></td>
                        <td><input type='submit' value='Search' name='btnofficer' /></td>
                    </tr>
                </table>
                <?php echo form_close(); ?>
                    <div class="pagination"><?php echo $this->pagination->create_links();?></div>
                    <br/>
                 
                    <?php foreach ($officers->result() as $soldier) :?>
                        <table class="table table-bordered">
                           
                            <tr>
                                <td rowspan="3"><img src="<?php echo base_url()?>uploads/passports/<?php echo $soldier->passport;?>" class="img-thumbnail" width="100" height="100"></td>
                                <th >Army No.:</th>
                                <td colspan="6"><?php echo $soldier->army_no?></td>

                            </tr>
                             <tr>
                               
                                <th>Full Name:</th>
                                <td colspan="6"><?php echo $soldier->surname?> &nbsp; &nbsp; <?php echo $soldier->firstname?> &nbsp; &nbsp; <?php echo $soldier->othername?></td>
                            </tr>
                            <tr>
                                <th>Rank</th>
                                <td colspan="6"><?php echo $soldier->rank?></td>

                            </tr>
                            <tr>
                                <th></th>
                                <td colspan="2"align="right"><a onclick="return confirm('Are you sure you want to delete?')" href="<?php echo base_url();?>admin/delete_officer/<?php echo $soldier->sold_id;?>">Delete Record</a></td>
                                <td colspan="2" align="right"><a href="<?php echo base_url();?>admin/edit_officer/<?php echo $soldier->sold_id;?>">Edit Record</a></td>
                                <td colspan="2" align="right"><a href="<?php echo base_url();?>admin/officer_details/<?php echo $soldier->sold_id;?>">More details</a></td>

                            </tr>
                       

                        </table>
            
                    <?php endforeach;?>
                
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>
