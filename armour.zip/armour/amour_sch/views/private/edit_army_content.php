<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content" style="border-right: 1px solid silver; border-bottom: 1px solid silver;">
            <div id="content_header"><p>Edit Soldier Data </p></div>
           <?php echo form_fieldset('Biographical Data'); ?>
            <?php if($this->session->flashdata('updated')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('updated');?></p>
            <?php endif;?>
            <?php echo validation_errors('<p class="text-danger">')?>
               <?php echo form_open_multipart('deliver_data/edit_army_data/'.$sdata->sold_id.'');?>
                        <table border="0" cellpadding="5" cellspacing="5" width="100%" id="form_data">
                            <tr>
                                
                               
                                <td align="right">
                                    <?php echo form_label('Army No:');?>
                                </td>
                                <td>
                                    
                                    <?php $data = array(
                                        'name' =>'army_no',
                                        'id'  =>'army_no',
                                        'disabled'  =>'disabled',
                                        'value' =>$sdata->army_no
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td></td>
                                <td></td> 
                                <td></td>
                                <td height="50">
                                    <img src="<?php echo base_url()?>uploads/passports/<?php echo $sdata->passport;?>" class="img-thumbnail" width="100" height="100">
                                     
                                </td>
                                
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Surname:');?></td>
                                <td>
                                     <?php $data = array(
                                        'name' =>'surname',
                                        'id'  =>'surname',
                                        'value' =>$sdata->surname
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td align="right"><?php echo form_label('Firstname:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'firstname',
                                        'id'  =>'firstname',
                                        'value' =>$sdata->firstname
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right"><?php echo form_label('Othername:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'othername',
                                        'id'  =>'othername',
                                        'value' =>$sdata->othername
                                    );?>
                                    <?php echo form_input($data);?>
                                    
                                </td>
                                 
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Sex:');?></td>
                                <td>
                                  
                                    <select name="gender"  style='width:50%;'>
                                        <option value="<?php echo $sdata->sex;?>"><?php echo $sdata->sex;?></option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                       
                                    </select>
                                </td>
                                
                                <td align="right"><?php echo form_label('Religion:');?></td>
                                <td>
                                     
                                    <select name="religion"  style='width:50%;'>
                                        <option value="<?php echo $sdata->religion;?>"><?php echo $sdata->religion;?></option>
                                        <option value="Islamic">Ismalic</option>
                                        <option value="Christianity">Christianity</option>
                                        <option value="Pegan">Pegan</option>
                                    </select>
                                </td>
                                <td align="right"><?php echo form_label('Tribe:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'tribe',
                                        'id'  =>'tribe',
                                        'value' =>$sdata->tribe
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Marital Status:');?></td>
                                <td>
                                   
                                    <select name="marital_status"  style='width:50%;'>
                                        <option value="<?php echo $sdata->marital_status;?>"><?php echo $sdata->marital_status;?></option>
                                        <option value="Single">Single</option>
                                        <option value="Married">Married</option>
                                        <option value="Widow">Widow</option>
                                        <option value="Divorce">Divorce</option>
                                    </select>
                                </td>
                                
                                <td align="right"><?php echo form_label('Date of Birth:');?></td>
                                <td>
                                   
                                     <input type="date" class="date" name="dob" value="<?php echo $sdata->dob;?>"/>
                                </td>
                                <td align="right"><?php echo form_label('Place of Birth:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'pob',
                                        'id'  =>'pob',
                                        'value' =>$sdata->pob
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Blood Group:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'bgroup',
                                        'id'  =>'bgroup',
                                        'value' =>$sdata->bgroup
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td align="right"><?php echo form_label('Height(ft):');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'height',
                                        'id'  =>'height',
                                        'value' =>$sdata->height
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right"><?php echo form_label('Weight(kg):');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'weight',
                                        'id'  =>'weight',
                                        'value' =>$sdata->weight
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                              <tr>
                                <td align="right"><?php echo form_label('Name of Spouse:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'spouse_name',
                                        'id'  =>'spouse_name',
                                        'value' =>$sdata->spouse_name
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td align="right"><?php echo form_label('No Of Children:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'noc',
                                        'id'  =>'noc',
                                        'value' =>$sdata->noc
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right"><?php echo form_label('Name of First Child:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'nofc',
                                        'id'  =>'nofc',
                                        'value' =>$sdata->nofc
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                             <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td valign="top" align="right"><?php echo form_label('State:');?></td>
                                <td valign="top">
                                    <select name="state" id="slct1" onchange="populate(this.id,'slct2')" style='width:50%;'>
                                        
                                        <option value="<?php echo $sdata->state;?>"><?php echo $sdata->state;?></option>
                                        <?php foreach ($states as $state) :?>
                                        <option value="<?php echo $state;?>"><?php echo $state;?></option>
                                        <?php endforeach;?>
                                    </select>
                                </td>
                                
                                <td valign="top" align="right"><?php echo form_label('LGA:');?></td>
                                <td valign="top">
                                    
                                    <select name="lga" id="slct2" style='width:50%;'>
                                        <option value="<?php echo $sdata->lga;?>"><?php echo $sdata->lga;?></select>
                                    </select>
                                </td>
                                <td align="right" valign="top" ><?php echo form_label('Contact Address:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'c_address',
                                        'id'  =>'c_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>$sdata->cont_address
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td valign="top" align="right"><?php echo form_label('Phone:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'phone',
                                        'id'  =>'phone',
                                        'value' =>$sdata->phone
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td valign="top" align="right"><?php echo form_label('Email:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'email',
                                        'id'  =>'denlistment',
                                        'value' =>$sdata->email
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td valign="top" align="right"><?php echo form_label('Residence Address:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'r_address',
                                        'id'  =>'r_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>$sdata->residence_address
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                            </tr>
                            
                        </table>
            <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Next of Kin I')?>
                <table border="0" cellpadding="5" cellspacing="5" id="nok" width="100%">
                    <tr>
                        <td align="right"><?php echo form_label('Next of Kin Name:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_name',
                                        'id'  =>'nok_name',
                                        'value' =>$sdata->nok_name
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                        <td align="right"><?php echo form_label('Next of Kin Relationship:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_relation',
                                        'id'  =>'nok_relation',
                                        'value' =>$sdata->nok_relationship
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Next of Kin Address:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_address',
                                        'id'  =>'nok_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>$sdata->nok_address
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                        <td align="right" valign="top"><?php echo form_label('Next of Kin Phone:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_phone',
                                        'id'  =>'nok_phone',
                                        'value' =>$sdata->nok_phone
                                    );?>
                                    <?php echo form_input($data);?>
                               </td>
                    </tr>
                </table>
            <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Next of Kin II')?>
                <table border="0" cellpadding="5" cellspacing="5" id="nok" width="100%">
                    <tr>
                        <td align="right"><?php echo form_label('Next of Kin Name:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_name',
                                        'id'  =>'nok2_name',
                                        'value' =>$sdata->nok2_name
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                        <td align="right"><?php echo form_label('Next of Kin Relationship:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_relation',
                                        'id'  =>'nok2_relation',
                                        'value' =>$sdata->nok2_relationship
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Next of Kin Address:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_address',
                                        'id'  =>'nok2_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>$sdata->nok2_address
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                        <td align="right" valign="top"><?php echo form_label('Next of Kin Phone:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_phone',
                                        'id'  =>'nok2_phone',
                                        'value' =>$sdata->nok2_phone
                                    );?>
                                    <?php echo form_input($data);?>
                               </td>
                    </tr>
                </table>
            <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Official Detail')?>
                <table border="0" cellpadding="5" cellspacing="5" id="nok" width="100%">
                    <tr>
                        <td align="right"><?php echo form_label('Present Rank:');?></td>
                         <td valign="top">
                                    
                             <select name="p_rank" style="width:80%;">
                                 <option value="<?php echo $sdata->rank?>" ><?php echo $sdata->rank?></option>
                                        <option value="Last Coperal" <?php echo set_select('p_rank','Last Coperal')?>>Last Coperal</option>
                                        <option value="Coperal" <?php echo set_select('p_rank','Coperal')?>>Coperal</option>
                                        <option value="Sergent" <?php echo set_select('p_rank','Sergent')?>>Sergent</option>
                                        <option value="Staff Sergent" <?php echo set_select('p_rank','Staff Sergent')?>>Staff Sergent</option>
                                        <option value="Warrant Officer" <?php echo set_select('p_rank','Warrant Officer')?>>Warrant Officer</option>
                                        <option value="Master Warrant Officer" <?php echo set_select('p_rank','Master Warrant Officer')?>>Master Warrant Officer</option>
                                        <option value="Army Warrant Officer" <?php echo set_select('p_rank','Army Warrant Officer')?>>Army Warrant Officer</option>
                                    </select>
                                </td>
                        <td align="right"><?php echo form_label('Type of Qualification:');?></td>
                         <td valign="top">
                                   
                             <select name="typeofqualification"  style='width:85%;'>
                                        <option value="<?php echo $sdata->typeofqualification;?>"><?php echo $sdata->typeofqualification;?></option>
                                        <option value="Civic Qualification">Civic Qualification</option>
                                        <option value="Military Qualification">Military Qualification</option>
                                        <option value="Trade Qualification">Trade Qualification</option>
                                        <option value="Other Qualification">Other Qualification</option>
                                       
                                    </select>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        
                                <td align="right" valign="top"><?php echo form_label('Ante Date:');?></td>
                          <td valign="top">
                                    
                               <input type="date" class="date" name="antedate" value="<?php echo $sdata->antedate;?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Desciplinary Cases:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'disciplinary_measure',
                                        'id'  =>'disciplinary_measure',
                                        'value' =>$sdata->disciplinary_measure
                                    );?>
                                    <?php echo form_input($data);?>
                             
                                </td>
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date of Enlistment:');?></td>
                          <td valign="top">
                                    
                               <input type="date" class="date" name="dateofenlistment" value="<?php echo $sdata->date_of_enlist;?>"/>
                                </td>
                                 <td align="right" valign="top"><?php echo form_label('Offence:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'offence',
                                        'id'  =>'offence',
                                        'value' =>$sdata->offence
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>  
                               
                         
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date Due for Promotion:');?></td>
                          <td valign="top">
                                    
                               <input type="date" class="date" name="dateofpromotion" value="<?php echo $sdata->dateofpromotion;?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Previous Unit:');?></td>
                          <td valign="top">
                                     <select name="previous_unit"  style='width:85%;'>
                                        
                                        <option value="<?php echo $sdata->previous_unit;?>"><?php echo $sdata->previous_unit;?></option>
                                        <?php foreach ($units as $unit) :?>
                                        <option value="<?php echo $unit->unit_name;?>"><?php echo $unit->unit_name;?></option>
                                        <?php endforeach;?>
                                        <option value="others">Others</option>
                                    </select>
                                </td>
                               
                                
                    </tr>
                    
                    <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Status:');?></td>
                          <td valign="top">
                                    
                               <select name="status"  style='width:85%;'>
                                        <option value="<?php echo $sdata->status;?>"><?php echo $sdata->status;?></option>
                                        <option value="Serving">Serving</option>
                                        <option value="Retired">Retired</option>
                                        <option value="Deceased">Deceased</option>
                                        <option value="KIA">KIA</option>
                                        <option value="MIA">MIA</option>
                                        <option value="Dismissed">Dismissed</option>
                                        <option value="Unknown">Unknown</option>
                                       
                                    </select>
                                </td>
                                 <td align="right" valign="top"><?php echo form_label('Present Unit:');?></td>
                          <td valign="top">
                                   <select name="present_unit"  style='width:85%;'>
                                        
                                       <option value="<?php echo $sdata->present_unit;?>"><?php echo $sdata->present_unit;?></option>
                                        <?php foreach ($units as $unit) :?>
                                        <option value="<?php echo $unit->unit_name;?>"><?php echo $unit->unit_name;?></option>
                                        <?php endforeach;?>
                                        <option value="others">Others</option>
                                    </select>
                                </td>  
                                
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date of Disciplinary Measure:');?></td>
                          <td valign="top">
                                    
                              <input type="date" class="date" name="dateofdiscip" value="<?php echo $sdata->discip_date;?>"/>
                                </td>
                               
                               
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                     <tr>
                        <td align="right" valign="top"><?php echo form_label('Nature of Engagement:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'natureofengagement',
                                        'id'  =>'natureofengagement',
                                        'value' =>$sdata->nature_of_engagement
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                     <tr>
                        <td align="right" valign="top"><?php echo form_label('Date TOS:');?></td>
                          <td valign="top">
                                   
                                    <input type="date" class="date" name="dateserved" value="<?php  echo $sdata->date_served;?>"/>
                                </td>
                               
                               
                    </tr>
                     
                   <tr>
                         <td><br/></td>
                     </tr>
                </table>
            <?php echo form_fieldset_close(); ?>
            <br/>
               <?php echo form_fieldset('Promotion History')?>
                <table border="0" cellpadding="5" cellspacing="5"  width="100%">
                          <tr>
                              <th>LCPL</th>
                              <th>Part 2 Orders</th>
                               <td valign="top">
                                    <?php $data = array(
                                        'name' =>'lcpl',
                                        'id'  =>'lcpl',
                                        'value' =>$sdata->lcpl
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                          </tr>
                          <tr>
                              <td><br/></td>
                          </tr>
                          <tr>
                              <th>CPL</th>
                              <th>Part 2 Orders</th>
                               <td valign="top">
                                    <?php $data = array(
                                        'name' =>'cpl',
                                        'id'  =>'cpl',
                                        'value' =>$sdata->cpl
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                          </tr>
                          <tr>
                              <td><br/></td>
                          </tr>
                           <tr>
                              <th>SGT</th>
                              <th>Part 2 Orders</th>
                               <td valign="top">
                                    <?php $data = array(
                                        'name' =>'sgt',
                                        'id'  =>'sgt',
                                        'value' =>$sdata->sgt
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                          </tr>
                           <tr>
                              <td><br/></td>
                          </tr>
                           <tr>
                              <th>SSGT</th>
                              <th>Part 2 Orders</th>
                               <td valign="top">
                                    <?php $data = array(
                                        'name' =>'ssgt',
                                        'id'  =>'ssgt',
                                       'value' =>$sdata->ssgt
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                          </tr>
                           <tr>
                              <td><br/></td>
                          </tr>
                           <tr>
                              <th>WO</th>
                              <th>Part 2 Orders</th>
                               <td valign="top">
                                    <?php $data = array(
                                        'name' =>'wo',
                                        'id'  =>'wo',
                                        'value' =>$sdata->wo
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                          </tr>
                </table>
             <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Bank Details')?>
                        <table border="0" cellpadding="5" cellspacing="5"  width="100%">
                            <tr>
                                <td align="right" valign="top"><?php echo form_label('Bank Name:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'bank_name',
                                        'id'  =>'bank_name',
                                        'value' =>$sdata->bank_name
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Bank Address:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'bank_address',
                                        'id'  =>'bank_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>$sdata->bank_address
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>  
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right" valign="top"><?php echo form_label('Account Name:');?></td>
                            <td valign="top">
                                       <?php $data = array(
                                          'name' =>'acct_name',
                                          'id'  =>'acct_name',
                                          'value' =>$sdata->acct_name
                                      );?>
                                        <?php echo form_input($data);?>
                                  </td>
                                <td align="right" valign="top"><?php echo form_label('Account no:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'acct_no',
                                        'id'  =>'acct_no',
                                        'value' =>$sdata->acct_no
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>  
                            </tr>
                            
                            
                             <tr>
                        <td colspan="8"><hr/></td>
                    </tr>
                     <tr>
                            <td colspan="2" align="right">
                                
                            </td>
                            <td colspan="2" align="left">
                                &nbsp; &nbsp;
                                <?php $data = array(
                                'name' =>'btnSave',
                                'value' =>'Update Record'
                            );?>

                            <?php echo form_submit($data);?>
                            </td>
                        </tr>
                </table>
                    
            <?php echo form_fieldset_close(); ?>
               <?php echo form_close();?>
            <br/>
            <br/>
            <center><a href="<?php echo base_url()?>admin/army_credentials/<?php echo $sdata->sold_id; ?>">View Credentials</a>&nbsp;|&nbsp;<a href="<?php echo base_url()?>admin/upload_army_credentials/<?php echo $sdata->sold_id; ?>">Upload Credentials</a></center>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>

<script type="text/javascript">
	$.datepicker.setDefaults({
		changeMonth : true,
		changeYear  : true,
		dateFormat  :'yy/mm/dd'
		
	});
	
	$(function(){
		$('.date').datepicker();
		$('body').delegate('input[type=date]',click,function(e)
		{
			$(this).datepicker();
		
		});
	});

</script>

