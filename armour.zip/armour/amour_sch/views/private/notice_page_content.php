<div id="admin_content">
    <div id="content_header">
        Notice from the Admin
    
    </div>
        <table aling="center" cellpadding="5" cellspacing="5" class="table table-bordered" width="100%">
            <tr>
                <th>Subject</th>
                <th><center>Message</center></th>
            </tr>
            <?php foreach($noticelist as $notice) :?>
               <tr>
                   <td><?php echo $notice->not_subject?></td>
                   <td><?php echo $notice->not_message?></td>
               </tr>

            <?php endforeach;?>
        </table>
    <br/>
           
</div>