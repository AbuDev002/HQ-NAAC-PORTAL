<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content" style="border-right: 1px solid silver; border-bottom: 1px solid silver;">
            <div id="content_header"><p>Enter Officer Data </p></div>
           <?php echo form_fieldset('Biographical Data'); ?>
            <?php if($this->session->flashdata('delivered')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('delivered');?></p>
            <?php endif;?>
            <?php echo validation_errors('<p class="text-danger">')?>
               <?php echo form_open_multipart('deliver_data/add_officer');?>
                        <table border="0" cellpadding="5" cellspacing="5" width="100%" id="form_data">
                            <tr>
                                
                               
                                <td align="right">
                                    <?php echo form_label('P/NO:');?>
                                </td>
                                <td>
                                    
                                    <?php $data = array(
                                        'name' =>'army_no',
                                        'id'  =>'army_no',
                                        'value' =>set_value('army_no')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td></td>
                                <td></td> 
                                <td><?php echo form_label('Passport:');?></td>
                                <td height="50">
                                     <input type="file" name="passport" size="20" />
                                   
                                </td>
                                
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Surname:');?></td>
                                <td>
                                     <?php $data = array(
                                        'name' =>'surname',
                                        'id'  =>'surname',
                                        'value' =>set_value('surname')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td align="right"><?php echo form_label('Firstname:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'firstname',
                                        'id'  =>'firstname',
                                        'value' =>set_value('firstname')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right"><?php echo form_label('Othername:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'othername',
                                        'id'  =>'othername',
                                        'value' =>set_value('othername')
                                    );?>
                                    <?php echo form_input($data);?>
                                    
                                </td>
                                 
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Sex:');?></td>
                                <td>
                                    <select name="gender" style="width:50%;">
                                        <option value="" <?php echo set_select('gender','',true)?>>---Select--</option>
                                        <option value="Male" <?php echo set_select('gender','Male')?>>Male</option>
                                        <option value="Female" <?php echo set_select('gender','Female')?>>Female</option>
                                    </select>
                                </td>
                                
                                <td align="right"><?php echo form_label('Religion:');?></td>
                                <td>
                                     <select name="religion" style="width:50%;">
                                        <option value="" <?php echo set_select('religion','',true)?>>---Select--</option>
                                        <option value="Islamic" <?php echo set_select('religion','Islamic')?>>Islamic</option>
                                        <option value="Christianity" <?php echo set_select('religion','Christianity')?>>Christianity</option>
                                        <option value="Pegan" <?php echo set_select('religion','Pegan')?>>Pegan</option>
                                    </select>
                                </td>
                                <td align="right"><?php echo form_label('Tribe:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'tribe',
                                        'id'  =>'tribe',
                                        'value' =>set_value('tribe')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Marital Status:');?></td>
                                <td>
                                   
                                    <select name="marital_status" style="width:50%;">
                                        <option value="" <?php echo set_select('marital_status','',true)?>>---Select--</option>
                                        <option value="Single" <?php echo set_select('marital_status','Single')?>>Single</option>
                                        <option value="Married" <?php echo set_select('marital_status','Married')?>>Married</option>
                                        <option value="Widow" <?php echo set_select('marital_status','Widow')?>>Widow</option>
                                        <option value="Divorce" <?php echo set_select('marital_status','Widow')?>>Divorce</option>
                                    </select>
                                </td>
                                
                                <td align="right"><?php echo form_label('Date of Birth:');?></td>
                                
                                <td>
                                   
                                     <input type="date" class="date" name="dob" value="<?php echo set_value('dob');?>"/>
                                </td>
                                <td align="right"><?php echo form_label('Place of Birth:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'pob',
                                        'id'  =>'pob',
                                        'value' =>set_value('pob')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            
                             <tr>
                                <td align="right"><?php echo form_label('Blood Group:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'bgroup',
                                        'id'  =>'bgroup',
                                        'value' =>set_value('bgroup')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td align="right"><?php echo form_label('Height(ft):');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'height',
                                        'id'  =>'height',
                                        'value' =>set_value('height')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right"><?php echo form_label('Weight(kg):');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'weight',
                                        'id'  =>'weight',
                                        'value' =>set_value('weight')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right"><?php echo form_label('Spouse Name:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'spouse_name',
                                        'id'  =>'spouse_name',
                                        'value' =>set_value('spouse_name')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td align="right"><?php echo form_label('No Of Children:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'noc',
                                        'id'  =>'noc',
                                        'value' =>set_value('noc')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right"><?php echo form_label('Name Of First Child & Date of Birth:');?></td>
                                <td>
                                    <?php $data = array(
                                        'name' =>'nofc',
                                        'id'  =>'nofc',
                                        'value' =>set_value('nofc')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                            </tr>
                             <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td valign="top" align="right"><?php echo form_label('State:');?></td>
                                <td valign="top">
                                    
                                     <select name="state" id="slct1" onchange="populate(this.id,'slct2')" style='width:50%;'>
                                        
                                        <option value="" <?php echo set_select('state','',true)?>>---Select---</option>
                                        <?php foreach ($states as $state) :?>
                                        <option value="<?php echo $state;?>" <?php echo set_select('state',$state)?>><?php echo $state;?></option>
                                        <?php endforeach;?>
                                    </select>
                                </td>
                                
                                <td valign="top" align="right"><?php echo form_label('LGA:');?></td>
                                <td valign="top">
                                    <?php $options = array(
                                        'default'    => '--Select--',
                                        
                                         );
                                    $style ='style="width:50%" id="slct2"'
                                       ?>
                                    <?php echo form_dropdown('lga',$options,'default',$style);?>
                                </td>
                                <td align="right" valign="top" ><?php echo form_label('Contact Address:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'c_address',
                                        'id'  =>'c_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>set_value('c_address')
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td valign="top" align="right"><?php echo form_label('Phone:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'phone',
                                        'id'  =>'phone',
                                        'value' =>set_value('phone')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                
                                <td valign="top" align="right"><?php echo form_label('Email:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'email',
                                        'id'  =>'denlistment',
                                        'value' =>set_value('email')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td valign="top" align="right"><?php echo form_label('Residence Address:');?></td>
                                <td valign="top">
                                    <?php $data = array(
                                        'name' =>'r_address',
                                        'id'  =>'r_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>set_value('r_address')
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                            </tr>
                            
                        </table>
                
            <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Next of Kin I')?>
                <table border="0" cellpadding="5" cellspacing="5" id="nok" width="100%">
                    <tr>
                        <td align="right"><?php echo form_label('Next of Kin Name:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_name',
                                        'id'  =>'nok_name',
                                        'value' =>set_value('nok_name')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                        <td align="right"><?php echo form_label('Next of Kin Relationship:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_relation',
                                        'id'  =>'nok_relation',
                                        'value' =>set_value('nok_relation')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Next of Kin Address:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_address',
                                        'id'  =>'nok_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>set_value('nok_address')
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                         <td align="right" valign="top"><?php echo form_label('Next of Kin Phone:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok_phone',
                                        'id'  =>'nok_phone',
                                        'value' =>set_value('nok_phone')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                </table>
            <?php echo form_fieldset_close(); ?>
            
            <br/>
            <?php echo form_fieldset('Next of Kin II')?>
                <table border="0" cellpadding="5" cellspacing="5" id="nok" width="100%">
                    <tr>
                        <td align="right"><?php echo form_label('Next of Kin Name:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_name',
                                        'id'  =>'nok2_name',
                                        'value' =>set_value('nok2_name')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                        <td align="right"><?php echo form_label('Next of Kin Relationship:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_relation',
                                        'id'  =>'nok2_relation',
                                        'value' =>set_value('nok2_relation')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Next of Kin Address:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_address',
                                        'id'  =>'nok2_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>set_value('nok2_address')
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>
                         <td align="right" valign="top"><?php echo form_label('Next of Kin Phone:');?></td>
                         <td valign="top">
                                    <?php $data = array(
                                        'name' =>'nok2_phone',
                                        'id'  =>'nok2_phone',
                                        'value' =>set_value('nok2_phone')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                </table>
            <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Official Detail')?>
                <table border="0" cellpadding="5" cellspacing="5"  width="100%">
                    <tr>
                        <td align="right"><?php echo form_label('Present Rank:');?></td>
                         <td valign="top">
                                    
                             <select name="p_rank" style="width:80%;">
                                        <option value="" <?php echo set_select('status','',true)?>>---Select--</option>
                                        <option value="Second Lieutenant" <?php echo set_select('p_rank','Second Lieutenant')?>>Second Lieutenant</option>
                                        <option value="Lieutenant" <?php echo set_select('p_rank','Lieutenant')?>>Lieutenant</option>
                                        <option value="Captain" <?php echo set_select('p_rank','Captain')?>>Captain</option>
                                        <option value="Lieutenant Colonel" <?php echo set_select('p_rank','Lieutenant Colonel')?>>Lieutenant Colonel</option>
                                        <option value="Colonel" <?php echo set_select('p_rank','Colonel')?>>Colonel</option>
                                        <option value="Brigadier General" <?php echo set_select('p_rank','Brigadier General')?>>Brigadier General</option>
                                        <option value="Major General" <?php echo set_select('p_rank','Major General')?>>Major General</option>
                                        <option value="Lieutenant General" <?php echo set_select('p_rank','Lieutenant General')?>>Lieutenant General</option>
                                        <option value="General" <?php echo set_select('p_rank','General')?>>General</option>
                                    </select>
                             
                                </td>
                        <td align="right"><?php echo form_label('Type of Commission:');?></td>
                         <td valign="top">
                               
                             <select name="typeofcommission" style="width:85%;">
                                        <option value="" <?php echo set_select('typeofcommission','',true)?>>---Select--</option>
                                        <option value="Regular Combatant" <?php echo set_select('typeofcommission','Regular Combatant')?>>Regular Combatant</option>
                                        <option value="Short Service" <?php echo set_select('typeofcommission','Short Service')?>>Short Service</option>
                                        <option value="Direct Short Service" <?php echo set_select('typeofcommission','Direct Short Service')?>>Direct Short Service</option>
                                        <option value="Executive Commission" <?php echo set_select('typeofcommission','Executive Commission')?>>Executive Commission</option>
                                    </select>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date of Commission:');?></td>
                          <td valign="top">
                                    
                              <input type="date" class="date" name="dateofcommission" value="<?php echo set_value('dateofcommission');?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Ante Date:');?></td>
                          <td valign="top">
                                   
                               <input type="date" class="date" name="antedate" value="<?php echo set_value('antedate');?>"/>
                              
                                </td>
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date of Enlistment(Executive Commission only):');?></td>
                          <td valign="top">
                                   
                              <input type="date" class="date" name="dateofenlistment" value="<?php echo set_value('dateofenlistment');?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Seniority Date:');?></td>
                          <td valign="top">
                                   
                               <input type="date" class="date" name="senioritydate" value="<?php echo set_value('senioritydate');?>"/>
                                </td>
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date Due for Promotion:');?></td>
                          <td valign="top">
                                   
                              <input type="date" class="date" name="dateofpromotion" value="<?php echo set_value('dateofpromotion');?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Run Out Date:');?></td>
                          <td valign="top">
                                    
                               <input type="date" class="date" name="runoutdate" value="<?php echo set_value('runoutdate');?>"/>
                                </td>
                    </tr>
                    
                    <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Status:');?></td>
                          <td valign="top">
                                  
                              <select name="status" style="width:80%;">
                                        <option value="" <?php echo set_select('status','',true)?>>---Select--</option>
                                        <option value="Serving" <?php echo set_select('status','Serving')?>>Serving</option>
                                        <option value="Retired" <?php echo set_select('status','Retired')?>>Retired</option>
                                        <option value="Deceased" <?php echo set_select('status','Deceased')?>>Deceased</option>
                                        <option value="KIA" <?php echo set_select('status','KIA')?>>KIA</option>
                                        <option value="MIA" <?php echo set_select('status','MIA')?>>MIA</option>
                                        <option value="Dismissed" <?php echo set_select('status','Dismissed')?>>Dismissed</option>
                                        <option value="Unknown" <?php echo set_select('status','Unknown')?>>Unknown</option>
                                    </select>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Desciplinary Cases:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'disciplinary_measure',
                                        'id'  =>'disciplinary_measure',
                                        'value' =>set_value('disciplinary_measure')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                    </tr>
                     <tr>
                         <td><br/></td>
                     </tr>
                    <tr>
                        <td align="right" valign="top"><?php echo form_label('Date of Disciplinary Case:');?></td>
                          <td valign="top">
                                   
                              <input type="date" class="date" name="dateofdiscip" value="<?php echo set_value('dateofdiscip');?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Offence:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'offence',
                                        'id'  =>'offence',
                                        'value' =>set_value('offence')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>  
                               
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                     <tr>
                        <td align="right" valign="top"><?php echo form_label('Nature of Engagement:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'natureofengagement',
                                        'id'  =>'natureofengagement',
                                        'value' =>set_value('natureofengagement')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Previous Unit:');?></td>
                          <td valign="top">
                                    <select name="previous_unit"  style='width:85%;'>
                                        
                                        <option value="" <?php echo set_select('previous_unit','',true)?>>---Select---</option>
                                        <?php foreach ($units as $unit) :?>
                                        <option value="<?php echo $unit->unit_name;?>" <?php echo set_select('previous_unit',$unit->unit_name)?>><?php echo $unit->unit_name;?></option>
                                        <?php endforeach;?>
                                        <option value="others">Others</option>
                                    </select>
                                </td>
                               
                    </tr>
                    <tr>
                         <td><br/></td>
                     </tr>
                     <tr>
                        <td align="right" valign="top"><?php echo form_label('Date TOS:');?></td>
                          <td valign="top">
                                    
                              <input type="date" class="date" name="dateserved" value="<?php echo set_value('dateserved');?>"/>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Present Unit:');?></td>
                                <td valign="top">
                                     <select name="present_unit"  style='width:85%;'>
                                        
                                        <option value="" <?php echo set_select('present_unit','',true)?>>---Select---</option>
                                        <?php foreach ($units as $unit) :?>
                                        <option value="<?php echo $unit->unit_name;?>"  <?php echo set_select('present_unit',$unit->unit_name)?>><?php echo $unit->unit_name;?></option>
                                        <?php endforeach;?>
                                        <option value="others">Others</option>
                                    </select>
                                </td>  
                               
                    </tr>
                     
                   <tr>
                         <td><br/></td>
                     </tr>
                </table>
            <?php echo form_fieldset_close(); ?>
            <br/>
            <?php echo form_fieldset('Bank Details')?>
                        <table border="0" cellpadding="5" cellspacing="5"  width="100%">
                            <tr>
                                <td align="right" valign="top"><?php echo form_label('Bank Name:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'bank_name',
                                        'id'  =>'bank_name',
                                        'value' =>set_value('bank_name')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>
                                <td align="right" valign="top"><?php echo form_label('Bank Address:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'bank_address',
                                        'id'  =>'bank_address',
                                        'style'  =>'width:220px; height:100px;',
                                        'value' =>set_value('bank_address')
                                    );?>
                                    <?php echo form_textarea($data);?>
                                </td>  
                            </tr>
                            <tr>
                                <td><br/></td>
                            </tr>
                            <tr>
                                <td align="right" valign="top"><?php echo form_label('Account Name:');?></td>
                            <td valign="top">
                                       <?php $data = array(
                                          'name' =>'acct_name',
                                          'id'  =>'acct_name',
                                          'value' =>set_value('acct_name')
                                      );?>
                                        <?php echo form_input($data);?>
                                  </td>
                                <td align="right" valign="top"><?php echo form_label('Account no:');?></td>
                          <td valign="top">
                                    <?php $data = array(
                                        'name' =>'acct_no',
                                        'id'  =>'acct_no',
                                        'value' =>set_value('acct_no')
                                    );?>
                                    <?php echo form_input($data);?>
                                </td>  
                            </tr>
                            
                            
                             <tr>
                        <td colspan="8"><hr/></td>
                    </tr>
                     <tr>
                            <td colspan="2" align="right">
                                <?php echo form_reset('reset','Reset');?>
                            </td>
                            <td colspan="2" align="left">
                                &nbsp; &nbsp;
                                <?php $data = array(
                                'name' =>'btnSave',
                                'value' =>'Save Entry'
                            );?>

                            <?php echo form_submit($data);?>
                            </td>
                        </tr>
                </table>
                    
            <?php echo form_fieldset_close(); ?>
               <?php echo form_close();?>
            
    
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>


<script type="text/javascript">
	$.datepicker.setDefaults({
		changeMonth : true,
		changeYear  : true,
		dateFormat  :'yy/mm/dd'
		
	});
	
	$(function(){
		$('.date').datepicker();
		$('body').delegate('input[type=date]',click,function(e)
		{
			$(this).datepicker();
		
		});
	});

</script>