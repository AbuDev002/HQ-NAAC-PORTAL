<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Send Notice All Officers & Soldiers </p></div>
            <br/>
            <br/>
            <?php if($this->session->flashdata('notice_delivered')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('notice_delivered');?></p>
            <?php endif;?>
            <center><?php echo validation_errors('<p class="text-danger">')?></center>
            <?php echo form_open('admin/send_notice');?>
                <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    <tr>
                        <td align="right"><?php //echo form_label('Course Name:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'subject',
                                'id'  =>'subject',
                                'placeholder'  =>'Enter Subject of the notice...',
                                'style' =>'width:100%',
                                'value' =>set_value('subject')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                   
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td valign="top" align="right"><?php //echo form_label('Course Qualification:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'message',
                                'id'  =>'message',
                                'placeholder'  =>'Enter Message...',
                                'style' =>'width:100%',
                                'value' =>set_value('message')
                            );?>
                            <?php echo form_textarea($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnNotice',
                                'id'  =>'cname',
                                'value' =>'Send'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>