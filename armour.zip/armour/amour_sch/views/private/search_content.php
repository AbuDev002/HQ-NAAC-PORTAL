<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Your Search Result</p></div>
            <br/>
            <br/>
            <?php if($this->session->flashdata('army_deleted')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('army_deleted');?></p>
            <?php endif;?>
               
                <br/>
               
               <?php echo $sresult?>
              
                
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>