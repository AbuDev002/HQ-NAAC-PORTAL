<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Add New Portal User </p></div>
            <br/>
           <center> <?php echo validation_errors('<p class="text-danger">');?></center>
           <?php if($this->session->flashdata('user_added')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('user_added');?></p>
            <?php endif;?>
            <?php echo form_open('deliver_data/add_new_user')?>
    <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    <tr>
                        <td align="right"><?php echo form_label('Username:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'user_name',
                                'id'  =>'user_name',
                                'style' =>'width:100%',
                                'value' =>set_value('user_name')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                    <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td align="right"><?php echo form_label('Password:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'password',
                                'id'  =>'password',
                                'style' =>'width:100%',
                                'value' =>set_value('password')
                            );?>
                            <?php echo form_password($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td align="right"><?php echo form_label('Confirm Password:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'cpassword',
                                'id'  =>'cpassword',
                                'style' =>'width:100%',
                                'value' =>set_value('cpassword')
                            );?>
                            <?php echo form_password($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td align="right"><?php echo form_label('Security Question:'); ?></td>
                        <td>

                            <select name ="security_question" style="width:100%;">
                                <option value="" <?php echo set_select('security_question','',true)?>>--Select--</option>
                                <option value="What is the name of your spouse?" <?php echo set_select('security_question','What is the name of your spouse?')?>>What is the name of your spouse?</option>
                                <option value="What is your street name?" <?php echo set_select('security_question','What is your street name?')?>>What is your street name?</option>
                                <option value="What is your favourite dish?" <?php echo set_select('security_question','What is your favourite dish?')?>> What is your favourite dish?</option>
                                <option value="What is your favourite color" <?php echo set_select('security_question','What is your favourite color')?>>What is your favourite color</option>
                                <option value="How do you always wake up in your bed" <?php echo set_select('security_question','How do you always wake up in your bed')?>>How do you always wake up in your bed</option>
                            </select>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                      <tr>
                        <td align="right"><?php echo form_label('Answer:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'answer',
                                'id'  =>'answer',
                                'style' =>'width:100%',
                                'value' =>set_value('answer')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                      <tr>
                        <td align="right"><?php echo form_label('Unit:'); ?></td>
                        <td>

                           <select name="unit"  style='width:100%;'>
                                        
                                <option value="" <?php echo set_select('unit','',true)?>>---Select---</option>
                                <?php foreach ($units as $unit) :?>
                                <option value="<?php echo $unit->unit_name;?>" <?php echo set_select('unit',$unit->unit_name)?>><?php echo $unit->unit_name;?></option>
                                <?php endforeach;?>
                            </select>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                    <tr>
                        <td align="right"><?php echo form_label('Status:'); ?></td>
                        <td>

                           <select name="status" style="width:50%;">
                                  <option value="" <?php echo set_select('status','',true)?>>--Select--</option>
                                  <option value="Active" <?php echo set_select('status','Active')?>>Active</option>
                                  <option value="Inactive" <?php echo set_select('status','Inactive')?>>Inactive</option>
                           </select>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                    <tr>
                        <td align="right"><?php echo form_label('Account Type:'); ?></td>
                        <td>
                              <select name="account_type" style="width:50%;">
                                  <option value="" <?php echo set_select('account_type','',true)?>>--Select--</option>
                                  <option value="Super Admin" <?php echo set_select('account_type','Super Admin')?>>Super Admin</option>
                                  <option value="Admin" <?php echo set_select('account_type','Admin')?>>Admin</option>
                                  <option value="User" <?php echo set_select('account_type','User')?>>User</option>
                              </select>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnAdd',
                                'id'  =>'unit_name',
                                'value' =>'Add'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>