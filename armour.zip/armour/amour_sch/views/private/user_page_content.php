<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Admin Users </p></div>
            <br/>
               <table class="table table-bordered" width="100%">
                   <tr>
                       <th>Username</th>
                       <th>Status</th>
                       <th>Account Type</th>
                       <th>Action</th>
                   </tr>
                   <?php foreach ($userslist as $users):?>
                    <tr>
                        <td><?php echo $users->username;?></td>
                        <td><?php echo $users->status;?></td>
                        <td><?php echo $users->account_type;?></td>
                        <td><a href="#">Deactivate</a></td>
                    </tr>
                   <?php endforeach;?>
               </table>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>