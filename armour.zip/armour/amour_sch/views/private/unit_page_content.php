<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>List of All Units </p></div>
            <br/>
            <div class="pagination"><?php echo $this->pagination->create_links();?></div>
            <table class="table table-bordered" cellpadding="5" cellspacing="5" width="100%">
                <tr>
                    <th>S/N</th>
                    <th>Name</th>
                    <th>Head</th>
                    <th>Unit Head PSN No.</th>
                    <th>Abbreviation</th>
                    <th>Description</th>
                </tr>
                
                <?php foreach ($listunits->result() as $allunit) :?>
                    <tr>
                        <td><?php  echo @$allunit->unit_id;?></td>
                        <td><?php  echo @$allunit->unit_name;?></td>
                        <td><?php  echo @$allunit->unit_head;?></td>
                        <td><?php  echo @$allunit->head_psn;?></td>
                        <td><?php  echo @$allunit->unit_abbreviation;?></td>
                        <td><?php  echo @$allunit->unit_description;?></td>
                     </tr
                <?php endforeach;?>
               >
             </table>
            
            
            
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>