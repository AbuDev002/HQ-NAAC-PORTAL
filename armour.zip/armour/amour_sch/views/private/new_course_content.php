<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Add  New Course </p></div>
            <br/>
            <br/>
            <?php if($this->session->flashdata('course_added')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('course_added');?></p>
            <?php endif;?>
            <center><?php echo validation_errors('<p class="text-danger">')?></center>
            <?php echo form_open('deliver_data/add_course');?>
                <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    <tr>
                        <td align="right"><?php //echo form_label('Course Name:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'course_name',
                                'id'  =>'course_name',
                                'placeholder'  =>'Course Name...',
                                'style' =>'width:100%',
                                'value' =>set_value('course_name')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                   
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td valign="top" align="right"><?php //echo form_label('Course Qualification:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'cqualif',
                                'id'  =>'cqualif',
                                'placeholder'  =>'Course Qualification',
                                'style' =>'width:100%',
                                'value' =>set_value('cqualif')
                            );?>
                            <?php echo form_textarea($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnAdd',
                                'id'  =>'cname',
                                'value' =>'Add Course'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>