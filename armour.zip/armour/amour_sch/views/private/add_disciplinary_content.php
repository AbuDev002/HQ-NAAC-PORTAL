<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Add Disciplinary Case </p></div>
            
            <?php if($this->session->flashdata('record_save')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('record_save');?></p>
            <?php endif;?>
            <br/>
            <br/>
            <center><?php echo validation_errors('<p class="text-danger">');?></center>
                <?php echo form_open();?>
                    <table align="center">
                        <tr>
                            <td><?php //echo form_label('Name:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'name'=>'staffid',
                                        'placeholder'=>'Enter P/No or Army No...',
                                        'style'=>'width:100%',
                                        'value'=>  set_value('staffid')
                                        );
                                ?>
                                <?php echo form_input($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td><br/></td>
                        </tr>
                        <tr>
                            <td><?php //echo form_label('Email:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'name'=>'offence',
                                        'placeholder'=>'Enter Offence...',
                                        'style'=>'width:100%',
                                        'value'=>  set_value('offence')
                                        );
                                ?>
                                <?php echo form_input($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td><br/></td>
                        </tr>
                       <tr>
                            <td><?php //echo form_label('Email:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'name'=>'action',
                                        'placeholder'=>'Enter Action taken...',
                                        'style'=>'width:100%',
                                        'value'=>  set_value('action')
                                        );
                                ?>
                                <?php echo form_input($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td><br/></td>
                        </tr>
                         <tr>
                            <td><?php //echo form_label('Email:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'name'=>'date',
                                        'placeholder'=>'Enter Date...',
                                        'style'=>'width:100%',
                                        'class'=>'date',
                                        'value'=>  set_value('date')
                                        );
                                ?>
                                <?php echo form_input($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td><br/></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <?php 
                                    $data = array(
                                        'name'=>'btnsave',
                                        'value'=>'Save',
                                        
                                        );
                                ?>
                                <?php echo form_submit($data);?>
                            </td>
                        </tr>
                     </table>
                <?php echo form_close()?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>


<script type="text/javascript">
	$.datepicker.setDefaults({
		changeMonth : true,
		changeYear  : true,
		dateFormat  :'yy/mm/dd'
		
	});
	
	$(function(){
		$('.date').datepicker();
		$('body').delegate('input[type=date]',click,function(e)
		{
			$(this).datepicker();
		
		});
	});

</script>