<div class="row">
    <?php $this->load->view('pages/admin_menu');?>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Add  New Unit </p></div>
            <br/>
            <br/>
            <?php if($this->session->flashdata('unit_inserted')):?>
                <p class="alert alert-success"><?php echo $this->session->flashdata('unit_inserted');?></p>
            <?php endif;?>
            <center><?php echo validation_errors('<p class="text-danger">')?></center>
            <?php echo form_open('deliver_data/insert_unit');?>
                <table align="center" cellspacing="5" cellpadding="5" width="50%" style="font-size:13px;">
                    <tr>
                        <td align="right"><?php //echo form_label('Unit Name:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'unit_name',
                                'id'  =>'unit_name',
                                'placeholder'  =>'Unit Name...',
                                'style' =>'width:100%',
                                'value' =>set_value('unit_name')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                    <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td align="right"><?php //echo form_label('Unit Head:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'unit_head',
                                'id'  =>'unit_head',
                                'placeholder'  =>'Unit Head...',
                                'style' =>'width:100%',
                                'value' =>set_value('unit_head')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td align="right"><?php //echo form_label('Head PSN No:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'head_username',
                                'id'  =>'head_username',
                                'placeholder'  =>'Head PSN No...',
                                'style' =>'width:100%',
                                'value' =>set_value('head_username')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td align="right"><?php //echo form_label('Unit Abbreviation:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'unit_abbr',
                                'id'  =>'unit_abbr',
                                'placeholder'  =>'Unit Abbreviation...',
                                'style' =>'width:100%',
                                'value' =>set_value('unit_abbr')
                            );?>
                            <?php echo form_input($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td valign="top" align="right"><?php //echo form_label('Unit Description:'); ?></td>
                        <td>

                            <?php $data = array(
                                'name' =>'unit_description',
                                'id'  =>'unit_description',
                                'placeholder'  =>'Unit Description...',
                                'style' =>'width:100%',
                                'value' =>set_value('unit_description')
                            );?>
                            <?php echo form_textarea($data);?>
                        </td>
                    </tr>
                     <tr>
                        <td><br/></td>
                    </tr>
                     <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnAdd',
                                'id'  =>'unit_name',
                                'value' =>'Add'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>