 <div class="container">
		<?php //echo heading('Login Page', 3);?>
<div class="row">
    <div class="col-md-4">
        
    </div>
    <div class="col-md-4">
        <!--Here the system is catching login message if the user typed incorrect login details-->
        <?php if($this->session->flashdata('login_failed')):?>
<p class="alert alert-danger"><?php echo $this->session->flashdata('login_failed');?></p>
<?php endif;?>


        <div class="panel panel-success">
            <div class="panel-heading">Secured Login System</div>
            <div class="panel-body">
                
                <?php echo validation_errors('<p class="text-danger">');?>
<?php $attributes = array('id' =>'loginForm', 'class' => 'form-horizontal');?>
<?php echo form_open('launch_page/login',$attributes);?>
    <p>
        <?php echo form_label('Army no/PSN:')?>
        
        <?php $data = array(
            'name' =>'username',
            'style' =>'width:90%',
            'autocomplete' =>'off',
            'value' =>set_value('username')
        );?>
        
        <?php echo form_input($data);?>
    </p>
    
     <p>
        <?php echo form_label('Password:')?>
        
        <?php $data = array(
            'name' =>'password',
            'autocomplete' =>'off',
            'style' =>'width:90%',
            'value' =>set_value('password')
        );?>
        
        <?php echo form_password($data);?>
    </p>
    
     <p>
        
        <?php $data = array(
            'name' =>'btnLogin',
            'value' =>'Login'
        );?>
        
        <?php echo form_submit($data);?>
    </p>

    
<?php echo form_close();?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
       
    </div>
</div>