 <div class="container">
		<?php echo heading('About Us', 3);?>
        <div class="row">
            <div class="col-md-6" style="text-align: justify;">
                <p>The Nigerian Army Armoured Corps is posed to win all battles in defence of the territorial integrity of Nigeria, protect her national interest
                and accomplish other tasks in aid of civil authority</p>
            </div>
            <div class="col-md-3">
                
            </div>
            <div class="col-md-3">
                
            </div>
        </div>

     
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>