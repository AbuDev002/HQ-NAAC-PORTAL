 <div class="container">
		 <div class="container">
		<div class="row">
            <div class="col-md-3" style="text-align: justify;">
                
            </div>
            <div class="col-md-6">
                <?php echo form_open();?>
                    <table>
                        <tr>
                            <td><?php //echo form_label('Name:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'name'=>'name',
                                        'placeholder'=>'Enter your name...',
                                        'style'=>'width:100%',
                                        'value'=>  set_value('name')
                                        );
                                ?>
                                <?php echo form_input($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td><br/></td>
                        </tr>
                        <tr>
                            <td><?php //echo form_label('Email:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'name'=>'email',
                                        'placeholder'=>'Enter your email...',
                                        'style'=>'width:100%',
                                        'value'=>  set_value('email')
                                        );
                                ?>
                                <?php echo form_input($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" align="center"><strong>Comment</strong></td>
                        </tr>
                        <tr>
                            <td><?php //echo form_label('Name:')?></td>
                            <td>
                                <?php 
                                    $data = array(
                                        
                                        'message'=>'message',
                                        'placeholder'=>'Write your comment...',
                                        'value'=>  set_value('message')
                                        );
                                ?>
                                <?php echo form_textarea($data)?>
                            </td>
                        </tr>
                        <tr>
                            <td><br/></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <?php 
                                    $data = array(
                                        'name'=>'btnComment',
                                        'value'=>'Send Comment',
                                        
                                        );
                                ?>
                                <?php echo form_submit($data);?>
                            </td>
                        </tr>
                     </table>
                <?php echo form_close()?>
            </div>
            <div class="col-md-3">
                
            </div>
        </div>

     
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
