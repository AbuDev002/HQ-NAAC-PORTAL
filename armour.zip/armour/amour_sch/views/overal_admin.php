<?php echo doctype('html5');?>
<html>
    <head>
        <title>
            <?php echo isset($title) ? $title : 'Default Title' ; ?>
        </title>
        <?php $this->load->view('layout_rules/style'); //include_once 'layout_rules/style.php'?>
        <?php $this->load->view('layout_rules/scripts'); //include_once 'layout_rules/scripts.php';?>
       
    </head>
    <body>
       
       <?php $this->load->view('pages/header_content'); //include_once 'pages/header_content.php';?>
        <br />
      <?php $this->load->view('pages/admin_nav'); //include_once 'pages/navigation.php';?>