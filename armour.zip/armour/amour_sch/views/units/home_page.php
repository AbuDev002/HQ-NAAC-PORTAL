<div id="admin_content">
    <div id="content_header">
        Welcome to <?php echo $this->session->userdata('unit_name');?>
    </div>
    <br/>
            <br/>
            
            
            
               
            
</div>