<div class="row">
    <?php //$this->load->view('pages/admin_menu');?>
    <div class="col-md-3">
    </div>
    <div class="col-md-7">
        <div id="admin_content">
            <div id="content_header"><p>Send Email </p></div>
            
            <br>
            <center><?php echo validation_errors('<p class="text-danger">');?>  <?php if(isset($message)){ echo '<p class="text-success">'.$message.'<p>';}?></center>
            <?php echo form_open('admin/of_collect_email')?>
            <table width="50%" align="center">
                <tr>
                    <td>
                       
                        <input type="text" name="getemail" style="width:100%;" value="<?php echo set_value('getemail');?>" placeholder="Enter Recipient PSN No...">
                    </td>
                    <td><input type="submit" name="btnsemail" value="Get Email"  style="width:100%;"/></td>
                </tr>
            </table>
            <?php echo form_close();?>
            <br/>
            <?php echo form_open('admin/of_email');?>
            <table width="50%" align="center">
                <tr>
                   
                    <td>
                         <?php $data = array(
                            'id'=>'email_no',
                            'name'=>'email_no',
                            'value'=>set_value('email_no'),
                            'style'=>'width:100%;',
                            'placeholder'=>'Enter Message Subject...',
                             
                        )?>
                        <?php echo form_input($data);?>
                       
                    </td>
                </tr>
                <tr>
                    <td><br/></td>
                </tr>
                 <tr>
                   
                    <td>
                        
                        <input type="text" name="email_to" style="width:100%;" value="<?php if(isset($usermail)){echo $usermail;}?>"  placeholder="Enter Email Address...">
                       
                    </td>
                </tr>
                <tr>
                    <td><br/></td>
                </tr>
                <tr>
                    
                    <td>
                        <?php $data = array(
                            'id'=>'message',
                            'name'=>'message',
                            'value'=>set_value('message'),
                            'style'=>'width:100%;',
                            'placeholder'=>'Write your message.....',
                        )?>
                        <?php echo form_textarea($data)?>
                    </td>
                </tr>
                <tr>
                    <td><br/></td>
                </tr>
                <tr>
                    <td><input type="submit" name="btnEmail" value="Send"></td>
                </tr>
            </table>
            <?php echo form_close();?>
        </div>
    </div>
    <div class="col-md-2">
       
    </div>
</div>