 <div class="container">
     <?php if($this->session->flashdata('noaccess')):?>
<p class="alert alert-danger"><?php echo $this->session->flashdata('noaccess');?></p>
<?php endif;?>
					<div class="row">
						
						<div class="col-md-8">
	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container0">
	<div class="ws_images"><ul>
            <li><img src="<?php echo base_url()?>data0/images/201503281714011715314731.jpg" alt="2015-03-28-17-14-01-1715314731" title="2015-03-28-17-14-01-1715314731" id="wows0_0"/></li>
		<li><img src="<?php echo base_url()?>data0/images/images1.jpg" alt="images-1" title="images-1" id="wows0_1"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003327.jpg" alt="IMG_00003327" title="IMG_00003327" id="wows0_4"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003328.jpg" alt="IMG_00003328" title="IMG_00003328" id="wows0_5"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003329.jpg" alt="IMG_00003329" title="IMG_00003329" id="wows0_6"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003330.jpg" alt="IMG_00003330" title="IMG_00003330" id="wows0_7"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003331.jpg" alt="IMG_00003331" title="IMG_00003331" id="wows0_8"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003332.jpg" alt="IMG_00003332" title="IMG_00003332" id="wows0_9"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003333.jpg" alt="IMG_00003333" title="IMG_00003333" id="wows0_10"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003336.jpg" alt="IMG_00003336" title="IMG_00003336" id="wows0_11"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003338.jpg" alt="IMG_00003338" title="IMG_00003338" id="wows0_12"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003339.jpg" alt="IMG_00003339" title="IMG_00003339" id="wows0_13"/></li>
		<li><img src="<?php echo base_url()?>data0/images/img_00003340.jpg" alt="IMG_00003340" title="IMG_00003340" id="wows0_14"/></li>
		<li><img src="<?php echo base_url()?>data0/images/1.jpg" alt="1" title="1" id="wows0_15"/></li>
		<li><img src="<?php echo base_url()?>data0/images/10.jpg" alt="10" title="10" id="wows0_16"/></li>
		<li><img src="<?php echo base_url()?>data0/images/24.jpg" alt="24" title="24" id="wows0_19"/></li>
		<li><a href="http://wowslider.com/vf"><img src="<?php echo base_url()?>data0/images/5.jpg" alt="full screen slider" title="full screen slider" id="wows0_22"/></a></li>
		<li><img src="<?php echo base_url()?>data0/images/7.jpg" alt="7" title="7" id="wows0_23"/></li>
	</ul></div>
<span class="wsl"><a href="http://wowslider.com/vu">image carousel</a> by WOWSlider.com v7.4</span>
	<div class="ws_shadow"></div>
	</div>	
	
	<!-- End WOWSlider.com BODY section -->
	
						</div>
                        
						<div class="col-md-4">
								<div class="well">
									
									<ul class="list-group">
										<!--<li class="list-group-item" ><li>-->
                                        <li class="list-group-item"><center><p><b><u>Latest News & Update</u><hr/></b></p><center><?php foreach($news_update as $update){ echo '<b> Posted no: '.$update->date_posted.'</b></br>'.$update->news_headline;}?> <a href="<?php echo base_url();?>launch_page/news_details/<?php echo $update->news_id;?>">Read More...</a><li>
										
									</ul>
								</div>
						</div>
					</div>
            <br/>
					<div class="row">
						<div class="col-md-4">
								<div class="well">
									<center><img src="<?php echo base_url();?>global/images/general.jpg" class="img-thumbnail" width="150" height="150"></center>
                                    <center><b>Maj Gen J N Nimyel &nbsp;  GSS psc (&plus;) mni </b></center>
									<center><b>Commander Nigerian Army Armoured Corps</b></center>
								</div>
                            <div class="well">
                            <center><a href="<?php echo base_url()?>/launch_page/commanders_profile" style="color:green;">View Profile of Commander Nigerian Army Armoured Corps</a></center>
                            </div>
						</div>
						<div class="col-md-4">
							<div class="well">
								<center><p><strong><u>COAS Vision</u></strong> </p>
                                <p>To optimize the capacity of the Nigerian Army to deal with national and global security challenges.
                                </p>
                                </center>
							</div>
                            <div class="well">
                                <a href="<?php echo base_url()?>/launch_page/nass_courses" style="color:green;">NAAS Schedule/Allocation of Courses</a>
                            </div>
                            <div class="well">
                                <a href="<?php echo base_url()?>/launch_page/units_orgniogarpy" style="color:green;">Organiograph of All Units</a>
                            </div>
							
						</div>
						<div class="col-md-4" style='text-align:justify;'>
							<b><u>About Armour Corps Portal</u></b>
							<p>The Nigerian Army Armoured Corps Portal is design to provide ICT facilities for effective Personnel Management and Dissemination
                            of working information using the state of the art ICT Technology <a href='<?php echo base_url();?>/launch_page/about_portal'>Read More...</a></p>
                            <hr/>
                            <b><u>Calender of Events</u></b>
                            <p>Nigerian Army Armoured Corps annual activities split into 12 months of the year falls into the following categories <a href='<?php echo base_url();?>/launch_page/calender_events'>Read More...</a></p>
                        </div>
					</div>
	