 <div class="container">
		<div class="row">
            <div class="col-md-6" style="text-align: justify;">
                <p><b>Email:</b> hq_naac@yahoo.com, &nbsp; info@hqnaacro.net</p>
                <p><b>Address:</b> Obienu Barrack, Kano Raod, Bauchi,Bauchi State.</p>
            </div>
            <div class="col-md-3">
                
            </div>
            <div class="col-md-3">
                
            </div>
        </div>

     
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>