<?php include 'pages/footer.php';?>

<script type="text/javascript" src="<?php echo base_url()?>engine0/wowslider.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>engine0/script.js"></script>
     </body>   
   
</html>

