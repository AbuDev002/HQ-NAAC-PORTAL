<div id="admin_content">
    <div id="content_header">
       Change Password
    </div>
    
    <br/>
    <?php if($this->session->flashdata('notification')):?>
<p class="alert alert-success"><?php echo $this->session->flashdata('notification');?></p>
<?php endif;?>
            <center><font color="red"><?php if(isset($pass_msg)){echo $pass_msg;}?></font></center>
           <?php echo form_open('users/change_password');?>
                <table align="center" cellspacing="5" cellpadding="5">
                    <tr>
                        <td>
                            <?php 
                                $data = array(
                                    'name'=>'cpassword',
                                    'placeholder'=>'Current Password....',
                                    'value' => set_value('cpassword')
                                    );
                            ?>
                        </td>
                        <td><?php echo form_password($data) ?></td>
                        <td><?php echo '<font color="red">'.form_error('cpassword').'</font>';?></td>
                    </tr>
                    <tr>
                        <td><br/></td>
                    </tr>
                    <tr>
                        <td>
                            <?php 
                                $data = array(
                                    'name'=>'newpassword',
                                    'placeholder'=>'New Password....',
                                    'value' => set_value('newpassword')
                                    );
                            ?>
                        </td>
                        <td><?php echo form_password($data) ?></td>
                         <td><?php echo '<font color="red">'.form_error('newpassword').'</font>';?></td>
                    </tr>
                    <tr>
                        <td><br/></td>
                    </tr>
                    <tr>
                        <td>
                            <?php 
                                $data = array(
                                    'name'=>'repassword',
                                    'placeholder'=>'Confirm Password....',
                                    'value' => set_value('repassword')
                                    );
                            ?>
                        </td>
                        <td><?php echo form_password($data) ?></td>
                         <td><?php echo '<font color="red">'.form_error('repassword').'</font>';?></td>
                    </tr>
                    <tr>
                        <td><br/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>

                            <?php $data = array(
                                'name' =>'btnUpdate',
                                'id'  =>'cname',
                                'value' =>'Update Password'
                            );?>
                            <?php echo form_submit($data);?>
                        </td>
                    </tr>
                    
                </table>
    
           <?php echo form_close();?>
</div>