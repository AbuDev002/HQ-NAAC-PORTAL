<div id="admin_content">
    <div id="content_header">
        Your Account ID is :: <?php echo $this->session->userdata('username');?>::
    </div>
    
    <br/>
            <?php foreach($csoldiers->result() as $soldier) :?>
                      <div class="panel panel-success">
					<div class="panel-heading">
                        <b> Welcome:::&nbsp;<?php echo $soldier->surname.'   '.$soldier->firstname.'  '.$soldier->othername;?></b>
					</div>
					<div class="panel-body">
						<div class="panel panel-success">
						<table class="table table-hover">
						<tr>
						
						<div class="panel-heading">

						</tr>
						<tr>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
						</tr>
						</div>
						<br/>
							
							<div class="panel-body">
								<table class="table table-bordered">
                                    <tr>
                                        <td></td>
										<th>Army No.</th>
										<td><?php echo $soldier->army_no; ?></td>
										
									</tr>
									<tr>
										<td rowspan="3"><img src="<?php echo base_url()?>uploads/passports/<?php echo $soldier->passport;?>" class="img-thumbnail" width="100" height="100"></td>
										<th>Full Name</th>
										<td><?php echo $soldier->surname.'   '.$soldier->firstname.'  '.$soldier->othername;?></td>
									</tr>
									
									<tr>
										<th>Rank</th>
										<td><?php echo $soldier->rank?></td>
										
									</tr>
									<tr>
										<th></th>
										
									</tr>
						
									
								</table>
								
							
								
							</div>
								<ul class="nav nav-tabs">
								  <li class="active"><a href="#personal_details" data-toggle="tab">Nigerian Army Personal Information</a></li>
								</ul>
								
								<div class="tab-content">
									<div class="tab-pane active" id="personal_details">
										<table class="table table-bordered">
											<tr class="success">
												<td colspan="5" align="center"><b>Bio Data</b></td>
											</tr>
											<tr>
												<th>Sur Name</th>
												<td><?php echo $soldier->surname;?></td>
                                                <th>First Name</th>
												<td><?php echo $soldier->firstname;?></td>
												<th>Other Name</th>
												<td><?php echo $soldier->othername;?></td>
												
											</tr>
											<tr>
												<th>Date of Birth</th>
												<td><?php echo $soldier->dob;?></td>
												<th>Sex</th>
												<td colspan="3"><?php echo $soldier->sex;?></td>
											</tr>
											<tr>
												<th>Place of Birth</th>
												<td><?php echo $soldier->pob;?></td>
												<th>State of Origin</th>
												<td colspan="3"><?php echo $soldier->state;?></td>
											</tr>
											<tr>
												<th>LGA</th>
												<td><?php echo $soldier->lga;?></td>
												<th>Contact Address</th>
												<td colspan="3"><?php echo $soldier->cont_address;?></td>
											</tr>
											<tr>
												<th>Mobile No.</th>
												<td><?php echo $soldier->phone;?></td>
												<th>Date of Enlistment</th>
												<td colspan="3"><?php echo $soldier->date_of_enlist;?></td>
											</tr>
                                            <tr>
												<th>Religion.</th>
												<td><?php echo $soldier->religion;?></td>
												<th>Tribe</th>
												<td colspan="3"><?php echo $soldier->tribe;?></td>
											</tr>
                                            <tr>
												<th>Marital Status.</th>
												<td><?php echo $soldier->marital_status;?></td>
												<th>Blood Group</th>
												<td colspan="3"><?php echo $soldier->bgroup;?></td>
											</tr>
                                            <tr>
												<th>Height(ft)</th>
												<td><?php echo $soldier->height;?></td>
												<th>Weight(kg)</th>
												<td colspan="3"><?php echo $soldier->weight;?></td>
											</tr>
                                            <tr>
												<th>Email</th>
												<td><?php echo $soldier->email;?></td>
												
											</tr>
											<tr class="success">
												<td colspan="5" align="center"><b>Next of I</b></td>
											</tr>
											<tr>
												<th>Next of Kin Name</th>
												<td><?php echo $soldier->nok_name;?></td>
												<th>Next of Kin Relationship</th>
												<td><?php echo $soldier->nok_relationship;?><td>
											</tr>
											<tr>
												<th>Next of Kin Address</th>
												<td><?php echo $soldier->nok_address;?></td>
                                                <th>Next of Kin Phone</th>
												<td><?php echo $soldier->nok_phone;?></td>
												
											</tr>
                                            <tr class="success">
												<td colspan="5" align="center"><b>Next of II</b></td>
											</tr>
											<tr>
												<th>Next of Kin Name</th>
												<td><?php echo $soldier->nok2_name;?></td>
												<th>Next of Kin Relationship</th>
												<td><?php echo $soldier->nok2_relationship;?><td>
											</tr>
											<tr>
												<th>Next of Kin Address</th>
												<td><?php echo $soldier->nok2_address;?></td>
                                                <th>Next of Kin Phone</th>
												<td><?php echo $soldier->nok2_phone;?></td>
												
											</tr>
											<tr class="success">
												<td colspan="5" align="center"><b>Official Details</b></td>
											</tr>
											<tr>
												<th>Present Rank</th>
												<td><?php echo $soldier->rank;?></td>
												<th>Type of Qualification</th>
												<td><?php echo $soldier->typeofqualification;?></td>
											</tr>
											<tr>
												<th>Ante Date</th>
												<td><?php echo $soldier->antedate;?></td>
												<th>Disciplinary Measure</th>
												<td><?php echo $soldier->disciplinary_measure;?></td>
											</tr>
											<tr>
												<th>Offense</th>
												<td><?php echo $soldier->offence;?></td>
												<th>Date of Promotion</th>
												<td><?php echo $soldier->dateofpromotion;?></td>
												
											</tr>
                                            <tr>
												<th>Previous Unit</th>
												<td><?php echo $soldier->previous_unit;?></td>
												<th>Date served</th>
												<td><?php echo $soldier->date_served;?></td>
												
											</tr>
                                            <tr>
												<th>Present Unit</th>
												<td><?php echo $soldier->present_unit;?></td>
												<th>Date of Discipline</th>
												<td><?php echo $soldier->discip_date;?></td>
												
											</tr>
                                            <tr>
												<th>Nature of Engagement</th>
												<td><?php echo $soldier->nature_of_engagement;?></td>
												
											</tr>
                                            <tr class="success">
												<td colspan="5" align="center"><b>Promotion History</b></td>
											</tr>
                                            <tr>
												<th>LCPL</th>
												<th>Part 2 Order</th>
												<td><?php echo $soldier->lcpl;?></td>
												
											</tr>
                                            <tr>
												<th>CPL</th>
												<th>Part 2 Order</th>
												<td><?php echo $soldier->cpl;?></td>
												
											</tr>
                                            <tr>
												<th>SGT</th>
												<th>Part 2 Order</th>
												<td><?php echo $soldier->sgt;?></td>
												
											</tr>
                                            <tr>
												<th>SSGT</th>
												<th>Part 2 Order</th>
												<td><?php echo $soldier->ssgt;?></td>
												
											</tr>
                                            <tr>
												<th>WO</th>
												<th>Part 2 Order</th>
												<td><?php echo $soldier->wo;?></td>
												
											</tr>
											<tr class="success">
												<td colspan="5" align="center"><b>Bank Details</b></td>
											</tr>
                                            
											<tr>
												<th>Bank Name</th>
												<td><?php echo $soldier->bank_name;?></td>
												<th>Bank Address</th>
												<td><?php echo $soldier->bank_address;?></td>
												
											</tr>
											<tr>
												<th>Account Name</th>
												<td><?php echo $soldier->acct_name;?></td>
												<th>Account No</th>
												<td><?php echo $soldier->acct_no;?></td>
												
											</tr>
											
										</table>
										<hr />
										<center><button type="button"><a href="#">View As Report</a></button></center>
									</div>
									
								</div>
						</div>
					</div>
            
                <?php endforeach;?>
                       
            
</div>