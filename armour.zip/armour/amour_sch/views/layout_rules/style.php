<!--<link rel="stylesheet" type="text/css" href="css/bootstrap.css">-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>global/css/datepicker.css">


<!--font awesome stylesheet-->
<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

<!--jquery-ui cdn css-->
<link rel="stylesheet" type="text/css" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">

<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>engine0/style.css" />
<!--bootstrap css-->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>global/css/united-bootstrap.min.css">

<!--Main style file-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>global/css/style.css">