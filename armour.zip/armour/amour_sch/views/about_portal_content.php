<div id='outside_content'>
    <div id='outside_content_header'>
        About Armoured Corps Portal
    </div>
    <br/>
    <p>The Nigeiran Army Armoured Corps Portal is designed to provide ICT facilities for effective Personnel Management
     and Dessimination of working information using the state of the art ICT Technology.</p>
    <p>Personnel can have an account in the portal from the Supper Admin overseeing the portal (NAAC RO). Credentials Management.
     Cloud Presence Management, Training Program Information, Office Information, Management Information System and host of other
    functions are integrated into this portal.</p>
</div>