<nav class="navbar navbar-default" role="navigation" id="nav" style="width:100%;">
	<div class="container">
		<button class="navbar-toggle" data-target=".navbar-responsive-collapse" data-toggle="collapse" type="button">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<div class="navbar-collapse collapse navbar-responsive-collapse">
		
			<ul class="nav navbar-nav">
                <li><a href="<?php echo base_url()?>launch_page/index">Home</a></li>
				<li><a href="<?php echo base_url()?>launch_page/about_page">About-us</a></li>
				<li><a href="<?php echo base_url()?>launch_page/contact_page">Contact-us</a></li>
				<li><a href="<?php echo base_url()?>launch_page/email_page">Comments</a></li>
				
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="<?php echo base_url()?>launch_page/login_page">Login</a></li>
			</ul>
			</div>
		</div>
	</div>
	
</nav><!--end of navigation bar-->