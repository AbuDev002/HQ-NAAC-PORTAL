<div class="well well-lg">
    Copyright &copy;  | <?php echo date('Y');?>, Nigerian Army Amoured Corps HeadQuarter All rights reserved 

    <ul id="connect" class="pull-right">
        <li><b>Designed By:</b><a href="http://www.gwanisoftware.com" target="_blank">&nbsp; Gwani software</a></li>

    </ul>
</div>