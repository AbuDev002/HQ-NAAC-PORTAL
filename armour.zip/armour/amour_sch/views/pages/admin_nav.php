<nav class="navbar navbar-default" role="navigation" id="nav">
	<div class="container">
		<button class="navbar-toggle" data-target=".navbar-responsive-collapse" data-toggle="collapse" type="button">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<div class="navbar-collapse collapse navbar-responsive-collapse">
		
			<ul class="nav navbar-nav">
                <li><a href="<?php echo base_url()?>admin/index">Home</a></li>
                <li><a href="<?php echo base_url()?>admin/army_page">Soldiers</a></li>
				<li><a href="<?php echo base_url()?>admin/officer_page">Officers</a></li>
				<li><a href="<?php echo base_url()?>admin/users_page">Users</a></li>
				<li><a href="<?php echo base_url()?>admin/records_page">Search</a></li>
				<li><a href="<?php echo base_url()?>admin/units_page">Units</a></li>
				<li><a href="<?php echo base_url()?>admin/upload_file">File Uploads</a></li>
				<li><a href="<?php echo base_url()?>admin/change_password">Change Password</a></li>
				
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="<?php echo base_url()?>launch_page/logout">Logout</a></li>
			</ul>
			</div>
		</div>
	</div>
	
</nav><!--end of navigation bar-->