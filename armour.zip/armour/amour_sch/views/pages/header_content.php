
<div  class="row" id="header_rows">
				<div class="col-sm-4" id="tank_img">
                    <a href="#"><img src="<?php echo base_url();?>global/images/logo.jpeg" class="img-circle" width="100" height="100"></a>
                    	
				</div>
				<div class="col-sm-4">
                    
						<h3>Nigerian Army Armoured Corps</h3> <font face="comic sans-ms"  color="red" style="font-weight: bolder; font-size:18px;"><i>Combat Arm of Decision...</i></font>
					
				</div>
				<div class="col-sm-4">
                       <a href="#"><img src="<?php echo base_url();?>global/images/amorlog.jpg" class="img-circle" width="100" align="right" height="100"></a>
					
						<br/><br/><br/><br/>
						<marquee onMouseover="stop();" onMouseout="start();" scrolldelay="200">Obienu Barracks, Kano road, Bauchi</marquee>
					
				</div>
				
			</div>