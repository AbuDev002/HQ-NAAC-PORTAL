<nav class="navbar navbar-default" role="navigation" id="nav">
	<div class="container">
		<button class="navbar-toggle" data-target=".navbar-responsive-collapse" data-toggle="collapse" type="button">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<div class="navbar-collapse collapse navbar-responsive-collapse">
		
			<ul class="nav navbar-nav">
                <li><a href="<?php echo base_url()?>unit_head/index">Home</a></li>
                <li><a href="<?php echo base_url()?>unit_head/change_password">Change Password</a></li>
                <li><a href="#">Officers</a></li>
                <li><a href="#">Soldiers</a></li>
				<li><a href="<?php echo base_url()?>admin/of_email">Send Message</a></li>
				<li><a href="#">View Messages</a></li>
				<li><a href="<?php echo base_url()?>unit_head/notice_board">Notice Board</a></li>
				
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="<?php echo base_url()?>launch_page/logout">Logout</a></li>
			</ul>
			</div>
		</div>
	</div>
	
</nav><!--end of navigation bar-->