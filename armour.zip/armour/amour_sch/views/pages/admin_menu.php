<div class="col-md-3">
        <div id="side_content">
    <table class="table table-bordered" align="center" width="100%">
        <tr>
            
            <td align="center" class="success"><b>Main Menu</b></td>
          
        </tr>
        <tr>
            <td>
              
                <div class="dropdown" id="dropdown">
				<input type="checkbox" id="drop1" />
                    <label for="drop1" class="dropdown_button">Add New Data <span class="arrow"></span></label>
                    <ul class="dropdown_content">
                        <li><a href="<?php echo base_url()?>admin/new_soldier_page">Add New Soldier</a></li>
                        <li><a href="<?php echo base_url()?>admin/new_officer_page">Add New Officer</a></li>
                        <li><a href="<?php echo base_url()?>admin/new_unit_page">Add New Unit</a></li>                                
                        <li><a href="<?php echo base_url()?>admin/new_course">Add New Course</a></li>                                                                
                        <li><a href="<?php echo base_url()?>admin/new_user">Add New User</a></li>                                                                
                        <li><a href="<?php echo base_url()?>admin/latest_update">Add Latest Update</a></li>                                                                
                        <li><a href="<?php echo base_url()?>admin/add_commander">Add Commanders Profile</a></li>                                                                
                        <li><a href="<?php echo base_url()?>admin/add_disciplinary_case">Add Disciplinary Case</a></li>                                
                        <li><a href="<?php echo base_url()?>admin/send_notice">Send Notice</a></li>                                

                    </ul>

                </div>
                  
            </td>
        </tr>
        <tr>
            
            <td align="center"><a href="<?php echo base_url()?>admin/check_users_page"><b>Check Users Log</b></a></td>
          
        </tr>
        <tr>
            <td align="center"><a href="<?php echo base_url()?>admin/send_email_page"><b>Send Email</b></a></td>
        </tr>
        <tr>
            <td align="center"><a href="http://www.gwanisoftware.com/sales/gwanisms.html" target="_blank"><b>Send SMS</b></a></td>
        </tr>
    </table>
</div>
    </div>