<div class="container">
                <h4>Past Commanders Profile</h4>
                     <?php foreach ($commanders->result() as $commander) :?>
                            <table class="table table-bordered">
                                   
									<tr>
										<td rowspan="3" width="150"><img src="<?php echo base_url()?>uploads/commanders/<?php echo $commander->com_passport;?>" class="img-thumbnail" width="100" height="100"></td>
										<th>Full Name</th>
										<td><?php echo $commander->com_name;?></td>
									</tr>
									
									<tr>
										<th>Rank</th>
										<td><?php echo $commander->rank;?></td>
										
									</tr>
                                    <tr>
										<th width="250">Date Served as Commander Armoured Corp</th>
										<td><?php echo $commander->datefrom.' - '. $commander->dateto;?></td>
										
									</tr>
									
								</table>
                     <?php endforeach;?>
    <div class="pagination"><?php echo $this->pagination->create_links();?></div>
    
    <hr/>
    <h4>GOCs Profile</h4>
</div>