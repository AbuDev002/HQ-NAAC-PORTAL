<div id='outside_content'>
    <div id='outside_content_header'>
        NASS Schedule/Allocation of Courses
    </div>
    <br/>
    
    <table class="table table-bordered">
        <tr>
            <th>S/N</th>
            <th>Course Name</th>
            <th>Course Qualification</th>
        </tr>
        <?php foreach ($listcourses->result() as $course) :?>
            <tr>
                <td><?php echo $course->course_id;?></td>
                <td><?php echo $course->course_name;?></td>
                <td><a data-toggle="modal" href="#myModal"  style="color:green;">View Qualification</a></td>
            </tr>
            
        <?php endforeach;?>
    </table>
    

    <div id="myModal" class="modal fade">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

                    <h4 class="modal-title">Course Qualification</h4>

                </div>

                <div class="modal-body">

                    <p><?php echo $course->course_qualification;?></p>

                </div>

            </div>

        </div>

    </div>


</div>