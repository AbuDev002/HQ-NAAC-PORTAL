<?php
    class Deliver_data extends CI_controller{
       public function __construct() {
            parent::__construct();
            if(!$this->session->userdata('logged_in')){
                $this->session->set_flashdata('noaccess','Sorry, you need to login to access this page');
                redirect('launch_page/index');
            }
        }
        public function add_army(){
            //here am trying to validate all form fiels to make the user supply all the required fies before submittng the form
            
            $this->form_validation->set_rules('army_no','Army Number','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('passport','Passport','trim|required|xss_clean');
            $this->form_validation->set_rules('surname','Sur Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('firstname','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('gender','Sex','trim|required|max_length[50]|xss_clean');
           // $this->form_validation->set_rules('religion','Religion','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('tribe','Tribe','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('marital_status','Marital Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dob','Date of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('pob','Place of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('bgroup','Blood Group','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('height','Height','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('weight','Weight','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('state','State','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('lga','Local Government Area','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('c_address','Contact Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('phone','Phone number','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|xss_clean|valid_email');
            $this->form_validation->set_rules('r_address','Residence Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_name','Next of Kin Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_relation','Next of Kin Relationship','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('p_rank','Present Rank','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('typeofcommission','Type of Commission','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('antedate','Ante Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofenlistment','Date of Enlistment','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('senioritydate','Seniority Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofpromotion','Date of Promotion','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('runoutdate','Run Out Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('status','Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('disciplinary_measure','Disciplinary Measure','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('offence','Offence','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('natureofengagement','Nature of Engagement','trim|required|max_length[50]|min_length[2]|xss_clean');
           
            if($this->form_validation->run()== FALSE){
               $data['units'] = $this->User_model->fetch_units();
                $data['states'] = $this->User_model->fetch_states();
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/new_soldier_content',$data);
                //$this->load->view('overall_footer');
            }else{
                $status = "";
                $message ="";
                $filename ='passport';
                
                
                $config['upload_path'] ='./uploads/passports/';
                $config['allowed_types'] ='jpg|jpeg|png|gif';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                $config['overwrite']     = FALSE;
                
                $this->load->library('upload',$config);
                
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
                }else{
                    $data =$this->upload->data();
                    $send_data =$this->User_model->insert_soldier($data['file_name']);
                    
                    if($send_data){
                        $this->session->set_flashdata('delivered','Data have been saved successfully');
                        redirect('admin/new_soldier_page');
                    }else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                   
                   
                }
                    @unlink($_FILES[$filename]);
            }
        }
        
        
         public function edit_army_data($sold_id){
             //this is the form validation for editing army data
            //$this->form_validation->set_rules('army_no','Army Number','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('passport','Passport','trim|required|xss_clean');
            $this->form_validation->set_rules('surname','Sur Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('firstname','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('gender','Sex','trim|required|max_length[50]|xss_clean');
           // $this->form_validation->set_rules('religion','Religion','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('tribe','Tribe','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('marital_status','Marital Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dob','Date of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('pob','Place of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('bgroup','Blood Group','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('height','Height','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('weight','Weight','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('state','State','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('lga','Local Government Area','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('c_address','Contact Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('phone','Phone number','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|xss_clean|valid_email');
            $this->form_validation->set_rules('r_address','Residence Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_name','Next of Kin Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_relation','Next of Kin Relationship','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('p_rank','Present Rank','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('typeofcommission','Type of Commission','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('antedate','Ante Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofenlistment','Date of Enlistment','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('senioritydate','Seniority Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofpromotion','Date of Promotion','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('runoutdate','Run Out Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('status','Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('disciplinary_measure','Disciplinary Measure','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('offence','Offence','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('natureofengagement','Nature of Engagement','trim|required|max_length[50]|min_length[2]|xss_clean');
           
            if($this->form_validation->run()== FALSE){
               $data['sdata'] = $this->User_model->get_soldier($sold_id);
               $data['units'] = $this->User_model->fetch_units();
                $data['states'] = $this->User_model->fetch_states();
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/edit_army_content',$data);
                //$this->load->view('overall_footer');
           /* }else{
                $status = "";
                $message ="";
                $filename ='passport';
                
                
                $config['upload_path'] ='./uploads/passports/';
                $config['allowed_types'] ='jpg|jpeg|png|gif';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                
                $this->load->library('upload',$config);
                
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
            * 
            */
                }else{
                    //$data =$this->upload->data();
                    $send_data =$this->User_model->edit_soldier($sold_id);
                   
                    
                    if($send_data){
                         //$this->User_model->update_unit_history($sold_id);
                        $this->session->set_flashdata('updated','Record has been updated');
                        redirect('admin/edit_army/'.$sold_id);
                    }
                    /*else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                   
                   
                }
                    @unlink($_FILES[$filename]);
                     * 
                     */
            }
        }
        
        //this method will add new office to the database
        public function add_officer(){
            $this->form_validation->set_rules('army_no','Army Number','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('passport','Passport','trim|required|xss_clean');
            $this->form_validation->set_rules('surname','Sur Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('firstname','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('gender','Sex','trim|required|max_length[50]|xss_clean');
           // $this->form_validation->set_rules('religion','Religion','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('tribe','Tribe','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('marital_status','Marital Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dob','Date of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('pob','Place of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('bgroup','Blood Group','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('height','Height','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('weight','Weight','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('state','State','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('lga','Local Government Area','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('c_address','Contact Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('phone','Phone number','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|xss_clean|valid_email');
            $this->form_validation->set_rules('r_address','Residence Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_name','Next of Kin Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_relation','Next of Kin Relationship','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('p_rank','Present Rank','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('typeofcommission','Type of Commission','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('antedate','Ante Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofenlistment','Date of Enlistment','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('senioritydate','Seniority Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofpromotion','Date of Promotion','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('runoutdate','Run Out Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('status','Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('disciplinary_measure','Disciplinary Measure','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('offence','Offence','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('natureofengagement','Nature of Engagement','trim|required|max_length[50]|min_length[2]|xss_clean');
           
            if($this->form_validation->run()== FALSE){
                
               $data['units'] = $this->User_model->fetch_units();
               
                $data['states'] = $this->User_model->fetch_states();
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/new_officer_content',$data);
                //$this->load->view('overall_footer');
            }else{
                $status = "";
                $message ="";
                $filename ='passport';
                
                
                $config['upload_path'] ='./uploads/passports/';
                $config['allowed_types'] ='jpg|jpeg|png|gif';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                $config['overwrite']     = FALSE;
                
                $this->load->library('upload',$config);
                
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
                }else{
                    $data =$this->upload->data();
                    $send_data =$this->User_model->insert_officer($data['file_name']);
                    
                    if($send_data){
                        $this->session->set_flashdata('delivered','Data have been saved successfully');
                        redirect('deliver_data/add_officer');
                    }else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                   
                   
                }
                    @unlink($_FILES[$filename]);
            }
        }
        
        //this method will allow user to edit officers data
        public function edit_officer_data($sold_id){
            //$this->form_validation->set_rules('army_no','Army Number','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('passport','Passport','trim|required|xss_clean');
            $this->form_validation->set_rules('surname','Sur Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('firstname','First Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('gender','Sex','trim|required|max_length[50]|xss_clean');
           // $this->form_validation->set_rules('religion','Religion','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('tribe','Tribe','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('marital_status','Marital Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dob','Date of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('pob','Place of Birth','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('bgroup','Blood Group','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('height','Height','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('weight','Weight','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('state','State','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('lga','Local Government Area','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('c_address','Contact Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('phone','Phone number','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('email','Email','trim|required|max_length[100]|min_length[5]|xss_clean|valid_email');
            $this->form_validation->set_rules('r_address','Residence Address','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_name','Next of Kin Name','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('nok_relation','Next of Kin Relationship','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('p_rank','Present Rank','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('typeofcommission','Type of Commission','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('antedate','Ante Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofenlistment','Date of Enlistment','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('senioritydate','Seniority Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('dateofpromotion','Date of Promotion','trim|required|max_length[50]|min_length[2]|xss_clean');
            //$this->form_validation->set_rules('runoutdate','Run Out Date','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('status','Status','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('disciplinary_measure','Disciplinary Measure','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('offence','Offence','trim|required|max_length[50]|min_length[2]|xss_clean');
            $this->form_validation->set_rules('natureofengagement','Nature of Engagement','trim|required|max_length[50]|min_length[2]|xss_clean');
           
            if($this->form_validation->run()== FALSE){
               $data['sdata'] = $this->User_model->get_officer($sold_id);
               $data['units'] = $this->User_model->fetch_units();
                $data['states'] = $this->User_model->fetch_states();
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/edit_officer_content',$data);
                //$this->load->view('overall_footer');
           /* }else{
                $status = "";
                $message ="";
                $filename ='passport';
                
                
                $config['upload_path'] ='./uploads/passports/';
                $config['allowed_types'] ='jpg|jpeg|png|gif';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                
                $this->load->library('upload',$config);
                
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
            * 
            */
                }else{
                    //$data =$this->upload->data();
                    $send_data =$this->User_model->edit_officer($sold_id);
                    
                    if($send_data){
                        $this->session->set_flashdata('updated','Record has been updated successfully');
                        redirect('admin/edit_officer/'.$sold_id);
                    }
                    /*else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                   
                   
                }
                    @unlink($_FILES[$filename]);
                     * 
                     */
            }
        }
        
        
        public function insert_unit(){
            $this->form_validation->set_rules('unit_name','Unit Name','trim|required|xss_clean');
            $this->form_validation->set_rules('unit_head','Unit Head','trim|required|xss_clean');
            $this->form_validation->set_rules('head_username','Head Username','trim|required|xss_clean');
            $this->form_validation->set_rules('unit_abbr','Unit Abbreviation','trim|required|xss_clean');
            $this->form_validation->set_rules('unit_description','Unit Description','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/new_unit_content');
             //$this->load->view('overall_footer');
            }else{
                
                $ins_unit = $this->User_model->insert_new_unit();
                 $this->session->set_flashdata('unit_inserted','New Unit has been added successfully');
                 redirect('admin/new_unit_page');
            }
        }
        
        //this method will add new courses to the list of courses
        public function add_course(){
            $this->form_validation->set_rules('course_name','Course Name','trim|required|xss_clean');
            $this->form_validation->set_rules('cqualif','Qualification','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $title['title'] ="Add Course | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/new_course_content');
             //$this->load->view('overall_footer');
            }else{
                
                $ins_unit = $this->User_model->add_new_course();
                 $this->session->set_flashdata('course_added','Course has been added successfully');
                 redirect('admin/new_course');
            }
        }
        
        
       
        
        public function add_new_user(){
            $this->form_validation->set_rules('user_name','User Name','trim|required|xss_clean');
            $this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[12]|matches[cpassword]|xss_clean');
            $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|min_length[6]|max_length[12]|xss_clean');
            $this->form_validation->set_rules('answer','Security Answer','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                 $title['title'] ="Admin-User | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/new_user_content');
             //$this->load->view('overall_footer');
            }else{
                
                $ins_unit = $this->User_model->add_new_user();
                 $this->session->set_flashdata('user_added','User added successfully');
                 redirect('admin/new_user');
            }
        }
        
        
        
    }
?>