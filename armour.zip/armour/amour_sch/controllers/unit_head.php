<?php
    class Unit_head extends CI_Controller{
        
         public function __construct() {
            parent::__construct();
            if(!$this->session->userdata('logged_in')){
                $this->session->set_flashdata('noaccess','Sorry, you need to login to access this page');
                redirect('launch_page/index');
            }
        }
        
        
        public function index(){
            $title['title'] ="Unit Head | Nigerian Army Armoured Corps";
            $this->load->view('units/overall_unit',$title);
            $this->load->view('units/home_page');
            //$this->load->view('overall_footer');
        }
        
        
        public function notice_board(){
            $data['noticelist'] = $this->User_model->get_notice();
            $title['title'] ="Unit Notice Board | Nigerian Army Armoured Corps";
            $this->load->view('units/overall_unit',$title);
            $this->load->view('private/notice_page_content',$data);
            //$this->load->view('overall_footer');
            
        }
        
         public function change_password(){
                $this->form_validation->set_rules('cpassword','Current Password','trim|required|xss_clean');
                $this->form_validation->set_rules('newpassword','New Password','trim|required|xss_clean|max_length[20]|min_length[6]');
                $this->form_validation->set_rules('repassword','Confirm Password','trim|required|xss_clean|matches[newpassword]');
            
                if($this->form_validation->run() == FALSE){
                    $data ['pass_msg'] = '';
                     $title['title'] ="Change Password | Nigerian Army Armoured Corps";
                    $this->load->view('units/overall_unit',$title);
                    $this->load->view('units/change_password_content',$data);
                    //$this->load->view('overall_footer');
                }else{
                    $sql =$this->db->select("*")->from("users")->where("username",$this->session->userdata("username"))->get();
                    
                    foreach($sql->result() as $key_info){
                        $db_password = $key_info->password;
                        $db_id = $key_info->user_id;
                    }
                    
                    if(md5($this->input->post('cpassword')) == $db_password){
                        $post_password = md5($this->input->post('newpassword'));
                        $update = $this->db->query("UPDATE users SET password = '$post_password' WHERE user_id = $db_id") or die(mysql_error());
                        if($update){
                            $this->session->set_flashdata('notification','Password has been updated');
                            redirect('unit_head/change_password');
                        }
                        
                    }else{
                        $data ['pass_msg'] = 'Current Password is Incorrect';
                         $title['title'] ="Change Password | Nigerian Army Armoured Corps";
                         $this->load->view('units/overall_unit',$title);
                         $this->load->view('units/change_password_content',$data);
                    //$this->load->view('overall_footer');
                    }
                }
           
        }
    }
?>
