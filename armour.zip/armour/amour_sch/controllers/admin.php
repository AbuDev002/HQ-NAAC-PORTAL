<?php
    class Admin extends CI_Controller{
        /*this construct method automatically get fired what it does is to very weather the client is access the admin area 
            from the url or form then its deny him if he is trying to access the page via url and ask him to login
         */
         public function __construct() {
            parent::__construct();
            if(!$this->session->userdata('logged_in')){
                $this->session->set_flashdata('noaccess','Sorry, you need to login to access this page');
                redirect('launch_page/index');
            }
        }
       //this method get fired automatically when the user provide the correct login details
        public function index(){
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/admin_home_content');
             //$this->load->view('overall_footer');
        }
        
        //This method get the list of all army and display then with pagination
        public function army_page(){
           
            $config['base_url'] ="http://localhost:8080/armour/admin/army_page";
             $config['per_page'] = 2;
             $config['num_links'] = 5;
             //$config['full_tag_open'] ='<div class="pagination">';
             //$config['full_tag_close'] ='<div id="pagination">';
             $config['total_rows'] = $this->db->get('soldiers')->num_rows();
             
             $this->pagination->initialize($config);
             
              $data['soldiers'] = $this->db->get('soldiers',$config['per_page'],$this->uri->segment(3));
              //$data['soldiers'] = $this->User_model->get_all_soldiers();
            
             $title['title'] ="Army | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/army_page_content',$data);
             //$this->load->view('overall_footer');
        }
        
        public function army_details($sid){
            $data['army'] = $this->User_model->get_soldier($sid);
            
             $title['title'] ="Army | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/army_details_content',$data);
             //$this->load->view('overall_footer');
        }
        
        public function edit_army($sid){
            $data['sdata'] = $this->User_model->get_soldier($sid);
               $data['units'] = $this->User_model->fetch_units();
                $data['states'] = $this->User_model->fetch_states();
             $title['title'] ="Army | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/edit_army_content',$data);
             //$this->load->view('overall_footer');
        }
        
        
        //for officers -----------------------------------------------------------------------------------------
         public function officer_details($sid){
            $data['army'] = $this->User_model->get_officer($sid);
            
             $title['title'] ="Army | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/officer_details_content',$data);
             //$this->load->view('overall_footer');
        }
        
        public function edit_officer($sid){
            $data['sdata'] = $this->User_model->get_officer($sid);
               $data['units'] = $this->User_model->fetch_units();
                $data['states'] = $this->User_model->fetch_states();
             $title['title'] ="Army | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/edit_officer_content',$data);
             //$this->load->view('overall_footer');
        }
        
        //This method fetch the list of all nigierian army officers and display them with pagination
         public function officer_page(){
             
             $config['base_url'] ="http://localhost:8080/armour/admin/officer_page";
             $config['per_page'] = 2;
             $config['num_links'] = 5;
             //$config['full_tag_open'] ='<div class="pagination">';
             //$config['full_tag_close'] ='<div id="pagination">';
             $config['total_rows'] = $this->db->get('army_officers')->num_rows();
             
             $this->pagination->initialize($config);
             
             $data['officers'] = $this->db->get('army_officers',$config['per_page'],$this->uri->segment(3));
             
             //$data['officers'] = $this->User_model->get_all_officers();
            
             $title['title'] ="Officers | Nigerian Army Armoured Corps";
             
             $this->load->view('overal_admin',$title);
             $this->load->view('private/officers_page_content',$data);
             //$this->load->view('overall_footer');
        }
        
         public function users_page(){
             $data['userslist'] = $this->User_model->get_users();
             $title['title'] ="Admin-Users | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/user_page_content',$data);
             //$this->load->view('overall_footer');
        }
        
         public function new_user(){
             $data['units'] = $this->User_model->fetch_units();
             $title['title'] ="Admin-User | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/new_user_content',$data);
             //$this->load->view('overall_footer');
        }
        
         public function records_page(){
                $this->form_validation->set_rules('sfield','Search','trim|required|xss_clean');
                //$this->form_validation->set_error_delimiters('<span class="error">', '</span>');
                
                if($this->form_validation->run() == FALSE){
                    $data['results'] = "";
                     
                    //$search_criteria = $this->input->post('qdata');
                    //$user_post = $this->input->post('sfield');
                    
                    
                    //$data['results'] = $this->User_model->get_search_result($search_criteria,$user_post);
                    $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                    
                    $this->load->view('overal_admin',$title);
                    $this->load->view('private/record_page_content',$data);
                }else{
                    
                    $search_criteria = $this->input->post('qdata');
                    $user_post = $this->input->post('sfield');
                    $data['results'] = $this->User_model->get_search_result($search_criteria,$user_post);
                    $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                    $this->load->view('overal_admin',$title);
                    $this->load->view('private/record_page_content',$data);
                    //$this->load->view('overall_footer');
                }
        }
        
         public function units_page(){
             $config['base_url'] ="http://localhost:8080/armour/admin/units_page";
             $config['per_page'] = 10;
             $config['num_links'] = 5;
             //$config['full_tag_open'] ='<div class="pagination">';
             //$config['full_tag_close'] ='<div id="pagination">';
             $config['total_rows'] = $this->db->get('units')->num_rows();
             
             $this->pagination->initialize($config);
             
             $data['listunits'] = $this->db->get('units',$config['per_page'],$this->uri->segment(3));
             
             //$data['listunits'] = $this->User_model->fetch_units();
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/unit_page_content',$data);
             //$this->load->view('overall_footer');
        }
        
         public function new_soldier_page(){
             
             $data['units'] = $this->User_model->fetch_units();
              $data['states'] = $this->User_model->fetch_states();
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/new_soldier_content',$data);
             //$this->load->view('overall_footer');
        }
        
          public function new_officer_page(){
              
              $data['units'] = $this->User_model->fetch_units();
              $data['states'] = $this->User_model->fetch_states();
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/new_officer_content',$data);
             //$this->load->view('overall_footer');
        }
        
        public function new_unit_page(){
            
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/new_unit_content');
             //$this->load->view('overall_footer');
        }
        
         public function new_course(){
             $title['title'] ="Add Course | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/new_course_content');
             //$this->load->view('overall_footer');
        }
        
        public function check_users_page(){
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/check_user_content');
             //$this->load->view('overall_footer');
        }
        
        public function send_email_page(){
            $data['message'] = '';
             $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/send_email_content',$data);
             //$this->load->view('overall_footer');
        }
        
        //This method send  message to the specified email address
        public function send_email(){
             
            $this->form_validation->set_rules('email_no','Army / PSN No','trim|required|xss_clean');
            $this->form_validation->set_rules('email_to','Email To','trim|required|xss_clean|valid_email');
            $this->form_validation->set_rules('message','Message Area','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $data['message'] = '';
                $army_no = $this->input->post('getemail');
                $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/send_email_content',$data);
                //$this->load->view('overall_footer');
            }else{
            
            $data['message'] = 'The email has been send sucessfully';
            
            $this->email->from(set_value('naadmin@naca.net'), set_value('NA Admin'));
            $this->email->to(set_value('email_to'));
            $this->email->subject(set_value('email_no'));
            $this->email->message(set_value('message'));
            
            $this->email->send();
            
            //echo $this->email->print_debugger();
            
            
            $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
            $this->load->view('overal_admin',$title);
            $this->load->view('private/send_email_content',$data);
                //$this->load->view('overall_footer');
        }
        }
        
        public function so_email(){
             
            $this->form_validation->set_rules('email_no','Army / PSN No','trim|required|xss_clean');
            $this->form_validation->set_rules('email_to','Email To','trim|required|xss_clean|valid_email');
            $this->form_validation->set_rules('message','Message Area','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $data['message'] = '';
                //$army_no = $this->input->post('getemail');
                 $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                $this->load->view('users/overall_user',$title);
                $this->load->view('users/users_email_content',$data);
                //$this->load->view('overall_footer');
            }else{
            
            $data['message'] = 'The email has been send sucessfully';
            
            $this->email->from(set_value('naadmin@naca.net'), set_value('NA Admin'));
            $this->email->to(set_value('email_to'));
            $this->email->subject(set_value('email_no'));
            $this->email->message(set_value('message'));
            
            $this->email->send();
            
            //echo $this->email->print_debugger();
            
            
            $data['message'] = '';
                //$army_no = $this->input->post('getemail');
                 $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                $this->load->view('users/overall_user',$title);
                $this->load->view('users/users_email_content',$data);
                //$this->load->view('overall_footer');
        }
        }
        
        
        public function of_email(){
             
            $this->form_validation->set_rules('email_no','Army / PSN No','trim|required|xss_clean');
            $this->form_validation->set_rules('email_to','Email To','trim|required|xss_clean|valid_email');
            $this->form_validation->set_rules('message','Message Area','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $data['message'] = '';
                //$army_no = $this->input->post('getemail');
                 $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                $this->load->view('units/overall_unit',$title);
                $this->load->view('units/unit_email_content',$data);
                //$this->load->view('overall_footer');
            }else{
            
            $data['message'] = 'The email has been send sucessfully';
            
            $this->email->from(set_value('naadmin@naca.net'), set_value('NA Admin'));
            $this->email->to(set_value('email_to'));
            $this->email->subject(set_value('email_no'));
            $this->email->message(set_value('message'));
            
            $this->email->send();
            
            //echo $this->email->print_debugger();
            
            
             $data['message'] = '';
                //$army_no = $this->input->post('getemail');
                 $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                $this->load->view('units/overall_unit',$title);
                $this->load->view('units/unit_email_content',$data);
                //$this->load->view('overall_footer');
        }
        }
        
        
        public function send_sms_page(){
             $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
             $this->load->view('overal_admin',$title);
             $this->load->view('private/send_sms');
             //$this->load->view('overall_footer');
        }
        
        public function add_disciplinary_case(){
            $this->form_validation->set_rules('staffid','Army / PSN No','trim|required|xss_clean');
            $this->form_validation->set_rules('offence','Offence ','trim|required|xss_clean');
            $this->form_validation->set_rules('action','Action Taken ','trim|required|xss_clean');
            $this->form_validation->set_rules('date','Date','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/add_disciplinary_content');
             //$this->load->view('overall_footer');
            }else{
                
                
                $save_data = $this->User_model->save_discip_case();
                if($save_data){
                        $this->session->set_flashdata('record_save','Data have been saved successfully');
                        redirect('admin/add_disciplinary_case');
                }
            }
            
             
        }
        
        
        public function add_commander(){
               
               $this->form_validation->set_rules('com_name','Name of Commander','trim|required|xss_clean');
               $this->form_validation->set_rules('rank','Rank of Commander ','trim|required|xss_clean');
               $this->form_validation->set_rules('datefrom','Year Starts Servic ','trim|required|xss_clean');
               $this->form_validation->set_rules('dateto','Date End Service','trim|required|xss_clean');
               
               if($this->form_validation->run() == FALSE){
               
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/new_commander_content');
             //$this->load->view('overall_footer');
               }else{
                   //$file = $this->input->post('filename');
                   
                    $status = "";
                    $message ="";
                    $filename ='commander_image';
                
                
                $config['upload_path'] ='./uploads/commanders/';
                $config['allowed_types'] ='|jpg|png|jpeg|gif';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                //$config['overwrite']     = FALSE;
                
                $this->load->library('upload',$config);
                
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
                }else{
                    $data =$this->upload->data();
                    $upload_file =$this->User_model->save_commander_profile($data['file_name']);
                    if($upload_file){
                        $this->session->set_flashdata('record_uploaded','Record has been saved');
                        redirect('admin/add_commander');
                    }else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                }
                @unlink($_FILES[$filename]);
                
                
               }
        }
        
        public function upload_army_credentials($id){
             
              //$this->form_validation->set_rules('credential_upload','File Name','trim|required|xss_clean');
               
               if($this->form_validation->run() == FALSE){
                   
                $data['sdata'] = $this->User_model->get_soldier($id);
                $title['title'] ="Upload Credentials | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/credentials_content',$data);
                //$this->load->view('overall_footer');
             
               }else{
                    $status = "";
                    $message ="";
                    $filename ='credential_upload';
                
                $config['upload_path'] ='./uploads/soldiers_credential/';
                $config['allowed_types'] ='pdf|doc|docx';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                //$config['overwrite']     = FALSE;
                
                $this->load->library('upload',$config);
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
                }else{
                    $data =$this->upload->data();
                    $upload_cred =$this->User_model->update_army_credential($data['file_name'],$id);
                    if($upload_cred){
                        $this->session->set_flashdata('credential_uploaded','Credentials Uploaded successfully');
                        redirect('admin/upload_army_credentials/'.$id);
                    }else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                }
                @unlink($_FILES[$filename]);
                
                
               }
        }
        
         public function delete_soldier($sold_id){
            //delete list
            $this->User_model->delete_officer($sold_id);
            //create message
             $this->session->set_flashdata('army_deleted','The army record has been deleted');
             redirect('admin/army_page');
            
        }
        
         public function delete_officer($sold_id){
            //delete list
            $this->User_model->delete_officer($sold_id);
            //create message
             $this->session->set_flashdata('army_deleted','The officer record has been deleted');
             redirect('admin/officer_page');
            
        }
        
        public function search(){
                $this->form_validation->set_rules('user_search','Search','trim|required|xss_clean');
                 
                if($this->form_validation->run()== FALSE){
                   $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                 $search = $this->input->post('user_search');
                 $data['sresult'] = $this->User_model->search_na($search); 
                $this->load->view('overal_admin',$title);
                $this->load->view('private/search_content',$data);
                }else{
                 
                 $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                 $search = $this->input->post('user_search');
                 $data['sresult'] = $this->User_model->search_na($search); 
                $this->load->view('overal_admin',$title);
                $this->load->view('private/search_content',$data);
                //$this->load->view('overall_footer');
                }
               
        }
        
        public function searchnao(){
                $this->form_validation->set_rules('searchofficer','Search','trim|required|xss_clean');
                 
                if($this->form_validation->run()== FALSE){
                   $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                 $searchofficer = $this->input->post('searchofficer');
                 $data['sresult'] = $this->User_model->search_nao($searchofficer); 
                $this->load->view('overal_admin',$title);
                $this->load->view('private/search_content',$data);
                }else{
                 
                 $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                 $searchofficer = $this->input->post('searchofficer');
                 $data['sresult'] = $this->User_model->search_nao($searchofficer); 
                $this->load->view('overal_admin',$title);
                $this->load->view('private/search_content',$data);
                //$this->load->view('overall_footer');
                }
               
        }
        
     
       public function collect_email(){
               $this->form_validation->set_rules('getemail','PSN No','trim|required|xss_clean');
               
                $army_no = $this->input->post('getemail');
               if($this->form_validation->run() == FALSE){
                    $data['usermail'] = '';
                    $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                    $this->load->view('overal_admin',$title);
                    $this->load->view('private/send_email_content',$data);
             //$this->load->view('overall_footer');
               }else{
                   $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                    $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                    $this->load->view('overal_admin',$title);
                    $this->load->view('private/send_email_content',$data);
                    //$this->load->view('overall_footer');
               }
           }
           
           public function so_collect_email(){
               $this->form_validation->set_rules('getemail','PSN No','trim|required|xss_clean');
               
                $army_no = $this->input->post('getemail');
               if($this->form_validation->run() == FALSE){
                    $data['usermail'] = '';
                    $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                    $this->load->view('overall_user',$title);
                    $this->load->view('users/users_email_content',$data);
             //$this->load->view('overall_footer');
               }else{
                   $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                    $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                    $this->load->view('users/overall_user',$title);
                    $this->load->view('users/users_email_content',$data);
                    //$this->load->view('overall_footer');
               }
           }
           
           public function of_collect_email(){
               $this->form_validation->set_rules('getemail','PSN No','trim|required|xss_clean');
               
                $army_no = $this->input->post('getemail');
               if($this->form_validation->run() == FALSE){
                    $data['usermail'] = '';
                    $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                    $this->load->view('overall_unit',$title);
                    $this->load->view('units/unit_email_content',$data);
             //$this->load->view('overall_footer');
               }else{
                   $army_no = $this->input->post('getemail');
                    $data['usermail'] =$this->User_model->get_email($army_no);
                    $title['title'] ="Admin-Email | Nigerian Army Armoured Corps";
                    $this->load->view('units/overall_unit',$title);
                    $this->load->view('units/unit_email_content',$data);
                    //$this->load->view('overall_footer');
               }
           }
           
           
           public function upload_file(){
               
               $this->form_validation->set_rules('filename','File Name','trim|required|xss_clean');
               
               if($this->form_validation->run() == FALSE){
               
                $title['title'] ="Admin-Home | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/file_upload_content');
                //$this->load->view('overall_footer');
               }else{
                   //$file = $this->input->post('filename');
                   
                    $status = "";
                    $message ="";
                    $filename ='file_upload';
                
                
                $config['upload_path'] ='./uploads/uploaded_files/';
                $config['allowed_types'] ='|gpg|pdf|doc|docx|xls|csv';
                $config['max_size'] = '1024';
                //$config['max_width'] = '250';
                //$config['max_height'] = '250';
                $config['encrypt_name'] = true;
                $config['overwrite']     = FALSE;
                
                $this->load->library('upload',$config);
                
                if(!$this->upload->do_upload($filename)){
                    $status ="error";
                    $message = $this->upload->display_errors('','');
                }else{
                    $data =$this->upload->data();
                    $upload_file =$this->User_model->insert_file_details($data['file_name']);
                    if($upload_file){
                        $this->session->set_flashdata('file_uploaded','File has been successfully');
                        redirect('admin/upload_file');
                    }else{
                        unlink($data['full_path']);
                        $status ="error";
                        $message ="Please try again";
                    }
                }
                @unlink($_FILES[$filename]);
                
                
               }
        }
        
        
         public function send_notice(){
            $this->form_validation->set_rules('subject','Subject of The Message','trim|required|xss_clean');
            $this->form_validation->set_rules('message','Message','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $title['title'] ="Send Notice | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/send_notice_content');
             //$this->load->view('overall_footer');
            }else{
                
                $ins_unit = $this->User_model->send_new_notice();
                 $this->session->set_flashdata('notice_delivered','Message delivered successfully');
                 redirect('admin/send_notice');
            }
        }
        
      
       
       public function latest_update(){
            $this->form_validation->set_rules('news_headline','News Headline','trim|required|xss_clean');
            $this->form_validation->set_rules('news_details','News Details','trim|required|xss_clean');
            $this->form_validation->set_rules('news_date','Date Posted','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                $title['title'] ="Add Latest News | Nigerian Army Armoured Corps";
                $this->load->view('overal_admin',$title);
                $this->load->view('private/latest_update_content');
             //$this->load->view('overall_footer');
            }else{
                
                $ins_unit = $this->User_model->add_news_update();
                 $this->session->set_flashdata('news_added','Update have been sent');
                 redirect('admin/latest_update');
            }
        }
        
    }
?>
