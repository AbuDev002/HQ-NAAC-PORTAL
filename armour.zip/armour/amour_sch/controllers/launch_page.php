<?php

class Launch_page extends CI_controller{
    //this function will get fired automatically when the clients launch the application
    public function index(){
        $data['news_update'] = $this->User_model->get_latest_update();
        $title['title'] ="Home | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('home_page_content',$data);
        $this->load->view('overall_footer');
    }
    
    
     
     public function nass_courses(){
             $config['base_url'] ="http://localhost:8080/armour/launch_page/nass_courses";
             $config['per_page'] = 10;
             $config['num_links'] = 5;
             //$config['full_tag_open'] ='<div class="pagination">';
             //$config['full_tag_close'] ='<div id="pagination">';
             $config['total_rows'] = $this->db->get('courses')->num_rows();
             
             $this->pagination->initialize($config);
             
             $data['listcourses'] = $this->db->get('courses',$config['per_page'],$this->uri->segment(3));
             $title['title'] ="Nass Courses | Nigerian Army Armoured Corps";
             $this->load->view('overall_header',$title);
             $this->load->view('nass_courses_content',$data);
             //$this->load->view('overall_footer');
        }
    
    //this function will automatically load the about page when the user hits the about link
    public function about_page(){
        $title['title'] ="About | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('about_page_content');
        $this->load->view('overall_footer');
    }
    
     public function commanders_profile(){
        
        
         $config['base_url'] ="http://localhost:8080/armour/launch_page/commanders_profile";
             $config['per_page'] = 2;
             $config['num_links'] = 5;
             //$config['full_tag_open'] ='<div class="pagination">';
             //$config['full_tag_close'] ='<div id="pagination">';
             $config['total_rows'] = $this->db->get('pass_commanders')->num_rows();
             
             $this->pagination->initialize($config);
             
              $data['commanders'] = $this->db->get('pass_commanders',$config['per_page'],$this->uri->segment(3));
              //$data['soldiers'] = $this->User_model->get_all_soldiers();
            
                $title['title'] ="About | Nigerian Army Armoured Corps";
                $this->load->view('overall_header',$title);
                $this->load->view('commanders_page_content',$data);
                //$this->load->view('overall_footer');
    }
    
    //This functio will automatically load the contact page when the user hits the contact link
    public function contact_page(){
        $title['title'] ="Contact | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('contact_page_content');
        $this->load->view('overall_footer');
    }
    
    //this function will automatically load the email page when the user hits the email link
    public function email_page(){
        $title['title'] ="Email | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('email_page_content');
        $this->load->view('overall_footer');
    }
    
    public function about_portal(){
        $title['title'] ="Email | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('about_portal_content');
        //$this->load->view('overall_footer');
    }
    
    public function calender_events(){
        
        $data['files'] = $this->User_model->get_uploaded_file();
        
        $title['title'] ="Calender Events | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('calender_events_content',$data);
        //$this->load->view('overall_footer');
    }
    
    public function news_details($nid){
        
        $data['news_update'] = $this->User_model->get_latest_news($nid);
        $title['title'] ="Calender Events | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('news_detail_content',$data);
        //$this->load->view('overall_footer');
    }
    
    //this function automatcially load the login page when the user hits on the login link
     public function login_page(){
        $title['title'] ="Login | Nigerian Army Armoured Corps";
        $this->load->view('overall_header',$title);
        $this->load->view('Login_page_content');
        //$this->load->view('overall_footer');
    }
    
    //this function validate form fiels and ensure that all the fiels are supplied before passing to the user_model
    public function login(){
            $this->form_validation->set_rules('username','User Name','trim|required|min_length[4]|xss_clean');
            $this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[12]|xss_clean');
            
            if($this->form_validation->run() == FALSE){
                //if the form is not submitted this login form will load by default
                $title['title'] ="Login | Nigerian Army Armoured Corps";
                $this->load->view('overall_header',$title);
                $this->load->view('login_page_content');
            }else{
                $username = $this->input->post('username');
                $password = $this->input->post('password');
                
                //Here am getting the user_id from the model user_login function
                $user_id = $this->User_model->login_user($username,$password);
                if($user_id){
                    $user_data = array(
                        'user_id' => $user_id->user_id,
                        'username' => $username,
                        'unit_name' => $user_id->unit_name,
                        'logged_in' => true
                    );
                    $this->session->set_userdata($user_data);
                    
                    //$last_login = date("Y-m-d H-i-s");
                    //$send = $this->User_model->update_login($data);
                    //$this->session->set_flashdata('login_success','You are now logged in');
                    if($user_id->account_type == 'Admin'){
                            redirect('Unit_head/index');
                    }elseif($user_id->account_type == 'User'){
                        redirect('users/index');
                    }else{
                        redirect('Admin/index');
                    }
                }else{
                    //send and error
                   $this->session->set_flashdata('login_failed','Access Denied For: Invalid Login Details or Inactive Account');
                    redirect('launch_page/login');
                }
            }
        }
        
        //this function will automatically logged the user out when the user hits on the logout link
        public function logout(){
            $this->session->unset_userdata('logged_in');
            $this->session->unset_userdata('user_id');
            $this->session->unset_userdata('username');
            $this->session->sess_destroy();
            
             $this->session->set_flashdata('logged_out','You have successfully logout');
             redirect('launch_page/login');
        }
    
}
?>